package ej3;

import java.util.ArrayList;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Alumno {

	private String nombre;
	private String email;
	private ArrayList<Materia> materiasCursadas;

	public Alumno(String nombre, String email) {
		
		this.materiasCursadas = new ArrayList<Materia>();
		setNombre(nombre);
		setEmail(email);
	}

	private void setNombre(String nombre) {
		this.nombre = nombre;
	}

	private void setEmail(String email) {
		this.email = email;
	}

	public int getCantMatAprobadas() {
		int cantMatAprobadas = 0;
		
		for(Materia m: this.materiasCursadas) {
			if(m.estaAprobada()) {
				cantMatAprobadas++;
			}
		}
		return cantMatAprobadas;
	}

	public void agregarMateria(Materia m) {
		this.materiasCursadas.add(m);
		
	}

	@Override
	public String toString() {
		return "Alumno [nombre=" + nombre + ", email=" + email + "]";
	}
	
	

}