package ej3;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Principal {

	public static void main(String[] args) {
		
		ORT ort = new ORT();
		cargarDatos(ort);
		
		ort.mostrarInformeDeCarreras();
		
	}
	
	
	public static void cargarDatos(ORT ort) {
		
		Carrera c1 = new Carrera("Analista de Sistemas");
		Carrera c2 = new Carrera("Diseño Grafico");
		
		Materia m1 = new Materia("THP", "2023-01", EstadoMateria.APROBADA);
		Materia m2 = new Materia("FDP", "2023-01",EstadoMateria.EN_CURSO);
		Materia m3 = new Materia("Matematica", "2023-01",EstadoMateria.REPROBADA);
		Materia m4 = new Materia("OEM", "2023-01",EstadoMateria.EN_CURSO);
		Materia m5 = new Materia("Ingles", "2023-01",EstadoMateria.APROBADA);
		
		Materia m6 = new Materia("Dibujo1", "2023-01",EstadoMateria.APROBADA);
		Materia m7 = new Materia("Diseño1", "2023-01",EstadoMateria.APROBADA);
		Materia m8 = new Materia("Computacion", "2023-01",EstadoMateria.APROBADA);
		Materia m9 = new Materia("TeoriaDiseño", "2023-01",EstadoMateria.REPROBADA);

		Alumno a1 = new Alumno("Juan Perez", "juanperez@gmail.com");
		Alumno a2 = new Alumno("Florencia Paez", "flopi@gmail.com");
		Alumno a3 = new Alumno("Pedro Alvarez", "coqui12@gmail.com");
		Alumno a4 = new Alumno("Magali Bermejo", "magakpa@gmail.com");
		
		ort.agregarCarrera(c1);
		ort.agregarCarrera(c2);
		
		/*Alumnos de Analista de sistemas*/
		a1.agregarMateria(m1);
		a1.agregarMateria(m2);
		a1.agregarMateria(m3);
		
		a2.agregarMateria(m1);
		a2.agregarMateria(m2);
		a2.agregarMateria(m3);
		a2.agregarMateria(m4);
		a2.agregarMateria(m5);
		
		/*Alumnos de Diseño grafico*/
		
		a3.agregarMateria(m6);
		a3.agregarMateria(m7);
		a3.agregarMateria(m8);
		
		a4.agregarMateria(m6);
		a4.agregarMateria(m7);
		a4.agregarMateria(m8);
		a4.agregarMateria(m9);
		
		c1.agregarAlumno(a1);
		c1.agregarAlumno(a2);
		
		c2.agregarAlumno(a3);
		c2.agregarAlumno(a4);
		
	}

}