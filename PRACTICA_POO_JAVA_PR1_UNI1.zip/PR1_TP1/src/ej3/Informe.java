package ej3;

	import java.util.ArrayList;
	
public class Informe {
	
	private int cantMaterias;
	private ArrayList<Alumno> alumnosMaxAprobados;
	
	

	public Informe(int cantMaxMaterias, ArrayList<Alumno> alumnosMasMatAprobadas) {
		this.alumnosMaxAprobados = alumnosMasMatAprobadas ;
		this.cantMaterias = cantMaxMaterias;	
		}
	
	private void listarAlumnos() {
		for(Alumno a: this.alumnosMaxAprobados) {
			System.out.println(a.toString());
		}
		
	}
	
	
	public void mostrarDatos() {
		System.out.println("Cantidad de materias: "+cantMaterias);
		listarAlumnos();
	}


	
	

	

}
