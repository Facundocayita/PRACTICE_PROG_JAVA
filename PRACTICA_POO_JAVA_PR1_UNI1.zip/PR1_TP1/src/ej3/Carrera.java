package ej3;

import java.util.ArrayList;

/**
 * Código generado por la app UXFtoJava by Charly Cimino
 * @see https://github.com/CharlyCimino/uxf-to-java
 */
public class Carrera {

	private String nombre;
	private ArrayList<Alumno> alumnos;

	public Carrera(String nombre) {
		this.alumnos = new ArrayList<Alumno>();
		setNombre(nombre);
	}



	private void setNombre(String nombre) {
		this.nombre = nombre;
	}



	private Informe getInformeMaxMaterias() {

		int cantMaxMaterias = obtenerCantMaxMateriasAprobadas();
		ArrayList<Alumno> alumnosMasMatAprobadas =  this.devolverListaAlumnosCantMatAprobadas(cantMaxMaterias);

		Informe informeMaxMaterias = new Informe(cantMaxMaterias, alumnosMasMatAprobadas);

		return informeMaxMaterias;
	}
	
	public void mostrarDatosInforme() {
		System.out.println("Carrera: "+this.nombre);
		getInformeMaxMaterias().mostrarDatos();
	}



	private ArrayList<Alumno> devolverListaAlumnosCantMatAprobadas(int cantMaterias) {
		ArrayList<Alumno> alumnosConCanMatAprobadas = new ArrayList<Alumno>();

		for(Alumno a: this.alumnos) {
			if(a.getCantMatAprobadas() == cantMaterias ) {
				alumnosConCanMatAprobadas.add(a);
			}
		}
		return alumnosConCanMatAprobadas;
	}



	private int obtenerCantMaxMateriasAprobadas() {
		int cantMaxMateriasAprobadas = 0;
		int materiasAprobadas = 0;

		for(Alumno a: this.alumnos) {
			materiasAprobadas = a.getCantMatAprobadas();
			if(materiasAprobadas > cantMaxMateriasAprobadas ) {
				cantMaxMateriasAprobadas = materiasAprobadas;
			}
		}
		return cantMaxMateriasAprobadas;
	}



	public void agregarAlumno(Alumno a) {
		this.alumnos.add(a);
		
	}

}