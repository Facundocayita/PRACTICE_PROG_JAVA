package ej3;

import java.util.ArrayList;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class ORT {

	
	private ArrayList<Carrera> carreras;

	public ORT() {
		this.carreras = new ArrayList<Carrera>();
	}
	
	public void mostrarInformeDeCarreras() {
		for(Carrera carrera: carreras) {
			carrera.mostrarDatosInforme();
		}
	}

	public void agregarCarrera(Carrera c1) {
		this.carreras.add(c1);
		
	}
	
	
	
	

}