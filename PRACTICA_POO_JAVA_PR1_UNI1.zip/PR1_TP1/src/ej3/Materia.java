package ej3;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Materia {

	private String nombre;
	private String cuatrimestre;
	private EstadoMateria estado;

	public Materia(String nombre, String cuatrimestre, EstadoMateria estado) {
		setNombre(nombre);
		setCuatrimestre(cuatrimestre);
		setEstado(estado);
		 
	}

	private void setNombre(String nombre) {
		this.nombre = nombre;
	}

	private void setCuatrimestre(String cuatrimestre) {
		this.cuatrimestre = cuatrimestre;
	}

	private void setEstado(EstadoMateria estado) {
		this.estado = estado;
	}

	
	public boolean estaAprobada() {
		boolean estaAprobada = false;
		if(this.estado.equals(EstadoMateria.APROBADA)) {
			estaAprobada = true;
		}
		return estaAprobada;
	}
	
	

}