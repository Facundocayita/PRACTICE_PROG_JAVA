package ej4;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Pieza {

	private String nombre;
	private boolean operativa;

	public Pieza(String nombre) {
		setNombre(nombre);
		setOperativa();
	}
	
	

	private void setNombre(String nombre) {
		this.nombre = nombre;
	}



	private void setOperativa() {
		this.operativa = true;
	}



	public void piezaRota() {
		this.operativa = false;
	}



	public boolean mismoNombre(String nombrePieza) {
		
		return this.nombre.equals(nombrePieza);
	}



	public String getNombre() {
		
		return this.nombre;
	}



	@Override
	public String toString() {
		return "Pieza [nombre=" + nombre + ", operativa=" + operativa + "]";
	}
	
	

}