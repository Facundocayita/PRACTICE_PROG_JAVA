package ej4;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Principal {

	public static void main(String[] args) {
		
		StarWars starWars = new StarWars();
		
		//cargarUniverso(starWars);
		
		Droide d1 = new Droide("R2D2", true);
		Droide d2 = new Droide("C3PO", true);
		Droide d3 = new Droide("BB-8", true);
		Droide d4 = new Droide("K-2SO", true);
		Droide d5 = new Droide("GA-97", true);
		Droide d6 = new Droide("Guerrero1", true);
		
		starWars.agregarDroide(d1);
		starWars.agregarDroide(d2);
		starWars.agregarDroide(d3);
		starWars.agregarDroide(d4);
		starWars.agregarDroide(d5);
		starWars.agregarDroide(d6);
	
		
		Pieza p1 = new Pieza("Batería de litio");
		Pieza p2 = new Pieza("Batería de litio");
		Pieza p3 = new Pieza("Batería de litio");
		Pieza p4 = new Pieza("Batería de litio");
		Pieza p5 = new Pieza("Batería de litio");
		Pieza p6 = new Pieza("Batería de litio");
		Pieza p7 = new Pieza("Torreta");
		Pieza p8 = new Pieza("Batería de litio");
		
		Pieza p9 = new Pieza("Sensor de proximidad");
		Pieza p10 = new Pieza("Sensor de proximidad");
		Pieza p11= new Pieza("Sensor de proximidad");
		Pieza p12= new Pieza("Sensor de proximidad");
		
		Pieza p13= new Pieza("Visor nocturno");
		Pieza p14 = new Pieza("Visor nocturno");
		Pieza p15 = new Pieza("Visor nocturno");
		Pieza p16 = new Pieza("Visor nocturno");
		Pieza p17 = new Pieza("Visor nocturno");
		Pieza p18 = new Pieza("Visor nocturno");
		
		//CREE PIEZAS Y DROIDES
		
		d1.agregarPieza(p1);
		d1.agregarPieza(p9);
		d1.agregarPieza(p13);
		
		
		d2.agregarPieza(p2);
		d2.agregarPieza(p10);
		d2.agregarPieza(p14);
		d2.piezaRota("Sensor de proximidad");
		d2.piezaRota("Batería de litio");
		
		d3.agregarPieza(p3);
		d3.agregarPieza(p11);
		d3.agregarPieza(p15);
		d3.agregarPieza(p7); //AGREGO TORRETA
		d3.piezaRota("Torreta");
		
		d4.agregarPieza(p4);
		d4.agregarPieza(p12);
		d4.agregarPieza(p16);
		d4.piezaRota("Visor nocturno");
		
		
		d5.agregarPieza(p5);
		d5.agregarPieza(p13);
		 
		d6.agregarPieza(p6);
		d6.agregarPieza(p17);
		d6.agregarPieza(p18);
		//AGREGUE DROIDES Y PIEZAS SANA Y ROTAS
		
		d4.droideRoto();
		d5.droideRoto();
		d6.droideRoto();
		//DROIDES FUERA DE SERVICIO
		
		d1.registrarDroideFueraServicio(d6);
		d1.registrarDroideFueraServicio(d5);
		d1.registrarDroideFueraServicio(d4);
		
		d2.registrarDroideFueraServicio(d6);
		d2.registrarDroideFueraServicio(d5);
		
		d3.registrarDroideFueraServicio(d6);
		d3.registrarDroideFueraServicio(d5);
		d3.registrarDroideFueraServicio(d4);
		
		
		System.out.println("NO OPERATIVAS");
		d1.mostrarPiezasNoOperativas();
		System.out.println("-------------------");
		System.out.println("OPERATIVAS");
		d1.mostrarPiezasOperativas();
		
		System.out.println("-------------------");
		System.out.println("DROIDES FUERA DE SERV. REGISTRADOS");
		
		d1.mostrarDroidesFueraServRegistrados();
		
		
		
	
		System.out.println(d1.autoRepararse());
		System.out.println(d2.autoRepararse());
		System.out.println(d3.autoRepararse());
		
		System.out.println("-------------------");
		System.out.println("NO OPERATIVAS DROIDE 3");
		d3.mostrarPiezasNoOperativas();
		
		
	}
	
	
	/*public static void cargarUniverso(StarWars starWars) {
		
		Droide d1 = new Droide("R2D2", true);
		Droide d2 = new Droide("C3PO", true);
		Droide d3 = new Droide("BB-8", true);
		Droide d4 = new Droide("K-2SO", true);
		Droide d5 = new Droide("GA-97", true);
		Droide d6 = new Droide("Guerrero1", true);
		
		starWars.agregarDroide(d1);
		starWars.agregarDroide(d2);
		starWars.agregarDroide(d3);
		starWars.agregarDroide(d4);
		starWars.agregarDroide(d5);
		starWars.agregarDroide(d6);
	
		
		Pieza p1 = new Pieza("Batería de litio");
		Pieza p2 = new Pieza("Batería de litio");
		Pieza p3 = new Pieza("Batería de litio");
		Pieza p4 = new Pieza("Batería de litio");
		Pieza p5 = new Pieza("Batería de litio");
		Pieza p6 = new Pieza("Batería de litio");
		Pieza p7 = new Pieza("Batería de litio");
		Pieza p8 = new Pieza("Batería de litio");
		
		Pieza p9 = new Pieza("Sensor de proximidad");
		Pieza p10 = new Pieza("Sensor de proximidad");
		Pieza p11= new Pieza("Sensor de proximidad");
		Pieza p12= new Pieza("Sensor de proximidad");
		
		Pieza p13= new Pieza("Visor nocturno");
		Pieza p14 = new Pieza("Visor nocturno");
		Pieza p15 = new Pieza("Visor nocturno");
		Pieza p16 = new Pieza("Visor nocturno");
		Pieza p17 = new Pieza("Visor nocturno");
		Pieza p18 = new Pieza("Visor nocturno");
		
		//CREE PIEZAS Y DROIDES
		
		d1.agregarPieza(p1);
		d1.agregarPieza(p9);
		d1.agregarPieza(p13);
		d1.piezaRota("Visor nocturno");
		
		d2.agregarPieza(p2);
		d2.agregarPieza(p10);
		d2.agregarPieza(p14);
		d2.piezaRota("Sensor de proximidad");
		d2.piezaRota("Batería de litio");
		
		d3.agregarPieza(p3);
		d3.agregarPieza(p11);
		d3.agregarPieza(p15);
		
		d4.agregarPieza(p4);
		d4.agregarPieza(p12);
		d4.agregarPieza(p16);
		
		d5.agregarPieza(p5);
		d5.agregarPieza(p13);
		 
		d6.agregarPieza(p6);
		d6.agregarPieza(p17);
		d6.agregarPieza(p18);
		//AGREGUE DROIDES Y PIEZAS SANA Y ROTAS
		
		d4.droideRoto();
		d5.droideRoto();
		d6.droideRoto();
		//DROIDES FUERA DE SERVICIO
		
		d1.registrarDroideFueraServicio(d6);
		d1.registrarDroideFueraServicio(d5);
		d1.registrarDroideFueraServicio(d4);
		
		d2.registrarDroideFueraServicio(d6);
		d2.registrarDroideFueraServicio(d5);
		
		d3.registrarDroideFueraServicio(d6);
		d3.registrarDroideFueraServicio(d5);
		d3.registrarDroideFueraServicio(d4);
		
	
		System.out.println(d1.autoRepararse());
		System.out.println(d2.autoRepararse());
		System.out.println(d3.autoRepararse());
		
		
		
		
	}*/

}