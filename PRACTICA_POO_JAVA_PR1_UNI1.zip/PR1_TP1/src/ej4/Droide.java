package ej4;

import java.util.ArrayList;

/**
 * Código generado por la app UXFtoJava by Charly Cimino
 * @see https://github.com/CharlyCimino/uxf-to-java
 */
public class Droide {

	private String nombre;
	private ArrayList<Droide> droidesFueraServicio;
	private boolean enServicio;
	private ArrayList<Pieza> piezasOperativas;
	private ArrayList<Pieza> piezasNoOperativas;

	public Droide(String nombre, boolean enServicio) {
		setNombre(nombre);
		setEnServicio(enServicio);
		piezasOperativas = new ArrayList<Pieza>();
		piezasNoOperativas = new ArrayList<Pieza>();
		droidesFueraServicio = new ArrayList<Droide>();
	}



	private void setNombre(String nombre) {
		this.nombre = nombre;
	}



	private void setEnServicio(boolean enServicio) {
		this.enServicio = enServicio;
	}

	public void droideRoto() {
		setEnServicio(false);
	}



	public void agregarPieza(Pieza pieza) {
		this.piezasOperativas.add(pieza);
	}

	public void piezaRota(String nombrePieza) {
		Pieza piezaEncontrada = buscarPieza(nombrePieza);
		if(piezaEncontrada != null) {
			this.piezasNoOperativas.add(piezaEncontrada);
			this.piezasOperativas.remove(piezaEncontrada);

			piezaEncontrada.piezaRota();
		}
	}

	private Pieza buscarPieza(String nombrePieza) {
		Pieza encontrada = null;
		int i = 0;

		while(i < this.piezasOperativas.size() && encontrada == null) {
			if(piezasOperativas.get(i).mismoNombre(nombrePieza)) {
				encontrada =  piezasOperativas.get(i);
			}else {
				i++;
			}	
		}
		return encontrada;
	}



	public void registrarDroideFueraServicio(Droide droide) {
		if(!droide.enServicio()) {
			this.droidesFueraServicio.add(droide);
		}
	}

	private boolean enServicio() {

		return this.enServicio;
	}



	public ResultadoRepararse autoRepararse() {
		ResultadoRepararse resultado = null;

		if(this.piezasNoOperativas.isEmpty()) {
			resultado = ResultadoRepararse.COMPLETAMENTE_OPERATIVO;

		}else if (reparacionPosible()) {
			if(this.piezasNoOperativas.isEmpty()) {
			}else {
				resultado = ResultadoRepararse.REPARACION_PARCIAL;
			}
		}else {
			resultado = ResultadoRepararse.REPARACION_IMPOSIBLE;
		}

		return resultado;
	}



	private boolean reparacionPosible() {
		boolean reparado =  false;
		Pieza piezaSana =  null;

		ArrayList<Pieza> pNoOperativasDescartar = new ArrayList<Pieza>();
		ArrayList<Pieza> pOperativasAgregar = new ArrayList<Pieza>();


		for(Pieza piezaRota: piezasNoOperativas) {
			piezaSana = buscarPiezaEnDroidesRotos(piezaRota.getNombre());
			if(piezaSana != null) {
				pNoOperativasDescartar.add(piezaRota);
				pOperativasAgregar.add(piezaSana);	
				reparado = true;
			}
		}

		if(reparado == true) {
			piezasNoOperativas.removeAll(pNoOperativasDescartar);
			piezasOperativas.addAll(pOperativasAgregar);
		}

		return reparado;
	}



	private Pieza buscarPiezaEnDroidesRotos(String nombre) {
		Pieza encontrada = null;
		int i = 0;

		while(i < this.droidesFueraServicio.size() && encontrada == null) {
			encontrada = droidesFueraServicio.get(i).buscarPieza(nombre);
			i++;
		}

		if(encontrada != null) {
			droidesFueraServicio.get(i).descartarPieza(encontrada);

		}

		return encontrada;
	}



	private void descartarPieza(Pieza encontrada) {
		this.piezasOperativas.remove(encontrada);

	}

	public void mostrarPiezasNoOperativas() {
		for(Pieza p: this.piezasNoOperativas) {
			System.out.println(p.toString());
		}
	}



	public void mostrarPiezasOperativas() {
		for(Pieza p: this.piezasOperativas) {
			System.out.println(p.toString());
		}

	}



	public void mostrarDroidesFueraServRegistrados() {
		for(Droide d: this.droidesFueraServicio) {
			System.out.println(d.toString());
		}

	}



	@Override
	public String toString() {
		return "Droide [nombre=" + nombre + ", enServicio=" + enServicio + "]";
	}



}