package ej4;

import java.util.ArrayList;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class StarWars {

	private ArrayList<Droide> droides;

	public StarWars() {
		this.droides =  new ArrayList<Droide>();
	}

	public void agregarDroide(Droide d) {
		this.droides.add(d);
		
	}
	
	
	
	

}