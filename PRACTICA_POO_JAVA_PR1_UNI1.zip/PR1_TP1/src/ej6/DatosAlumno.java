package ej6;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class DatosAlumno {

	private String nombre;
	private String mail;
	
	
	public DatosAlumno(String nombre, String mail) {
		setNombre(nombre);
		setMail(mail);
		
	}


	private void setNombre(String nombre) {
		this.nombre = nombre;
	}


	private void setMail(String mail) {
		this.mail = mail;
	}


	@Override
	public String toString() {
		return "Alumno [nombre=" + nombre + ", mail=" + mail + "]";
	}
	
	

	
	
}