package ej6;

import java.util.ArrayList;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Alumno {

	private String nombre;
	private String mail;
	private ArrayList<Materia> materiasAprobadas;

	public Alumno(String nombre, String mail) {
			setNombre(nombre);
			setMail(mail);
			this.materiasAprobadas =  new ArrayList<Materia>();
	}

	public void agregarMateria(Materia materia) {
		this.materiasAprobadas.add(materia);
	}

	public boolean cumpleRequisitos(int minMatAprob, double promedioMinimo) {
		boolean cumple = false;
		
		if(this.materiasAprobadas.size() >= minMatAprob ) {
			if(this.calcularPromedio() >= promedioMinimo) {
				cumple = true;
			}
		}
		return cumple;
	}

	private double calcularPromedio() {
		double promedio = 0;
		double sumaNotas = 0;
		
		for(Materia m: materiasAprobadas) {
			sumaNotas += m.getNotaFinal();
		}
		
		promedio = sumaNotas / materiasAprobadas.size();
		return promedio;
	}

	private void setNombre(String nombre) {
		this.nombre = nombre;
	}

	private void setMail(String mail) {
		this.mail = mail;
	}

	public DatosAlumno devolverDatosAlumnos() {
		DatosAlumno datos = new DatosAlumno(nombre, mail);
		return datos;
	}

	public void agregarListaMaterias(ArrayList<Materia> materias) {
		this.materiasAprobadas.addAll(materias);
		
	}
	
	

}