package ej6;

import java.util.ArrayList;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Carrera {

	private String nombre;
	private static final int MAX_CAND_LISTA = 20;
	private static final int MIN_MATER_APRO = 5;
	private ArrayList<Alumno> alumnos;

	public Carrera(String nombre) {
		setNombre(nombre);
		this.alumnos =  new ArrayList<Alumno>();
	}
	
	

	private void setNombre(String nombre) {
		this.nombre = nombre;
	}



	public ArrayList<DatosAlumno> obtenerCandidatos(double promedio) {
		ArrayList<DatosAlumno> candidatos = new ArrayList<DatosAlumno>();
		int cantCandidatos = 0;
		int i = 0;
		
		while(i < this.alumnos.size() && cantCandidatos < MAX_CAND_LISTA) {
			
			if(this.alumnos.get(i).cumpleRequisitos(MIN_MATER_APRO,promedio)) {
				candidatos.add(this.alumnos.get(i).devolverDatosAlumnos());
				cantCandidatos++;
			}
			i++;
		}
		
		return candidatos;
	}



	public boolean mismoNombre(String nombreCarrera) {
		
		return this.nombre == nombreCarrera;
	}



	public void imprimirListaCandidatos(double promedio) {
		ArrayList<DatosAlumno> listaCandidatos = new ArrayList<DatosAlumno>();
		int  cantAlumno = 1;
		listaCandidatos = obtenerCandidatos(promedio);
		System.out.println("Carrera: "+this.nombre);
		for(DatosAlumno datosAlum: listaCandidatos) {
			System.out.println("Numero: "+cantAlumno);
			System.out.println(datosAlum.toString());
			cantAlumno++;
		}
	}



	public void agregarAlumno(Alumno a) {
		this.alumnos.add(a);
		
	}

}