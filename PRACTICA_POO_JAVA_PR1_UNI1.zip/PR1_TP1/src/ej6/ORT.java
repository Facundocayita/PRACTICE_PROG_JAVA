package ej6;

import java.util.ArrayList;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class ORT {

	ArrayList<Carrera> carreras;
	
	public ORT() {
		this.carreras = new ArrayList<Carrera>();
	}
	
	public void imprimirListaCandidatos(String nombreCarrera, double promedio) {
		Carrera carrera = buscarCarrera(nombreCarrera);
		
		if(carrera != null) {
			carrera.imprimirListaCandidatos(promedio);
		}else {
			System.out.println("CARRERA NO ENCONTRADA");
		}
		
		
	}

	private Carrera buscarCarrera(String nombreCarrera) {
		Carrera encontrada = null;
		int i = 0;
		
		if(!carreras.isEmpty()) {
			while(i < carreras.size() && encontrada == null) {
				if(this.carreras.get(i).mismoNombre(nombreCarrera)) {
					encontrada = this.carreras.get(i);
				}
				i++;
			}
		}
		
		return encontrada;
	}

	public void agregarCarrera(Carrera c) {
		if(!this.carreras.contains(c)) {
			this.carreras.add(c);
		}
		
	}

}