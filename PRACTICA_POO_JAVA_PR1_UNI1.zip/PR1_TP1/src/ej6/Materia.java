package ej6;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Materia {

	private String nombre;
	private double notaFinal;

	public Materia(String nombre, double notaFinal) {
		setNombre(nombre);
		setNotaFinal(notaFinal);
	}

	private void setNombre(String nombre) {
		this.nombre = nombre;
	}

	private void setNotaFinal(double notaFinal) {
		this.notaFinal = notaFinal;
	}

	public double getNotaFinal() {
		return notaFinal;
	}
	
	
	

}