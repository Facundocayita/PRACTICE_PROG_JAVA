package ej6;

import java.util.ArrayList;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Principal {

	public static void main(String[] args) {
		Alumno a1 = new Alumno("Jorge Fernandez", "j.fernandez@gmail.com");
		Alumno a2 = new Alumno("Sofia Rozados", "s.rozados@gmail.com");
		Alumno a3 = new Alumno("Carla Martinez", "c.martinez@gmail.com");
		Alumno a4 = new Alumno("Lisandro Martinez", "l.martinez@gmail.com");
		Alumno a5 = new Alumno("Lautaro Martinez", "la.martinez@gmail.com");
		Alumno a6 = new Alumno("Nicolas Tagliafico", "n.tagliafico@gmail.com");
		Alumno a7 = new Alumno("Susana Gimenez", "s.gimenez@gmail.com");
		Alumno a8 = new Alumno("Morian Casan", "m.casan@gmail.com");
		Alumno a9 = new Alumno("Morena Beltran", "m.beltran@gmail.com");
		Alumno a10 = new Alumno("Colo Barco", "c.barco@gmail.com");
		Alumno a11= new Alumno("Oscar Romero", "o.romero@gmail.com");
		Alumno a12 = new Alumno("Melina Gutierrez", "m.gutierrez@gmail.com");
		Alumno a13 = new Alumno("Patricia Orosco", "p.orosco@gmail.com");
		Alumno a14 = new Alumno("Franco Casella", "f.casella@gmail.com");
		Alumno a15 = new Alumno("Pedro Bermudez", "p.bermudez@gmail.com");
		Alumno a16 = new Alumno("Marta Ayala", "m.ayala@gmail.com");
		Alumno a17 = new Alumno("Ana Bolina", "a.bolina@gmail.com");
		Alumno a18 = new Alumno("Diego Salvatierra", "d.salvatierra@gmail.com");
		Alumno a19 = new Alumno("Diego Monteros", "d.monteros@gmail.com");
		Alumno a20 = new Alumno("Lucas Alvarez", "l.alvarez@gmail.com");
		Alumno a21 = new Alumno("Juan Cimini", "j.cimini@gmail.com");
		Alumno a22 = new Alumno("Elias Aina", "e.ainai@gmail.com");
		Alumno a23 = new Alumno("Elisa Pedri", "e.pedri@gmail.com");
		
		Carrera c1 = new Carrera("Analista de Sistemas");
		Carrera c2 = new Carrera("Produccion Musical");
		Carrera c3 = new Carrera("Lic. Psicologia");
		
		
		Materia m1 = new Materia("OEM", 6.50);
		Materia m2 = new Materia("Ingles", 5.33);
		Materia m3 = new Materia("Matematica", 8.77);
		Materia m4 = new Materia("THP", 4.55);
		Materia m5 = new Materia("FDP", 8.40);
		Materia m6 = new Materia("IIF", 9);
		Materia m7 = new Materia("PR1", 10);
		Materia m8 = new Materia("TP1", 10);
		Materia m9 = new Materia("ASO", 10);
		Materia m10 = new Materia("Prog. Nuevas Tecnologis",10);
		
		Materia m11 = new Materia("Psicoanalisis", 6.50);
		Materia m12 = new Materia("Psico Gral", 6.50);
		Materia m13 = new Materia("Neuropsicologia", 6.50);
		
		
		
		ORT ort = new ORT();
		
		ArrayList<Materia> listaM1 = new ArrayList<Materia>();
		ArrayList<Materia> listaM2 = new ArrayList<Materia>();
		ArrayList<Materia> listaM3 = new ArrayList<Materia>();
		
		listaM1.add(m1);
		listaM1.add(m2);
		listaM1.add(m3);
		listaM1.add(m4);
		listaM1.add(m5);
		listaM1.add(m6);
	
		
		
		listaM2.add(m1);
		listaM2.add(m2);
		listaM2.add(m3);
		listaM2.add(m4);
		listaM2.add(m5);
		listaM2.add(m6);
		listaM2.add(m7);
		listaM2.add(m8);
		listaM2.add(m9);
		listaM2.add(m10);
		
		listaM3.add(m11);
		listaM3.add(m12);
		listaM3.add(m13);
		
		
		
		agregarListaMaterias(a1, listaM1);
		agregarListaMaterias(a2, listaM1);
		agregarListaMaterias(a3, listaM1);
		agregarListaMaterias(a4, listaM1);
		agregarListaMaterias(a5, listaM1);
		agregarListaMaterias(a6, listaM1);
		
		agregarListaMaterias(a7, listaM2);
		agregarListaMaterias(a8, listaM2);
		agregarListaMaterias(a9, listaM2);
		agregarListaMaterias(a10, listaM2);
		agregarListaMaterias(a11, listaM2);
		agregarListaMaterias(a12, listaM2);
		agregarListaMaterias(a13, listaM2);
		agregarListaMaterias(a14, listaM2);
		agregarListaMaterias(a15, listaM2);
		agregarListaMaterias(a16, listaM2);
		agregarListaMaterias(a17, listaM2);
		agregarListaMaterias(a18, listaM2);
		agregarListaMaterias(a19, listaM2);
		
		agregarListaMaterias(a20, listaM3);
		agregarListaMaterias(a21, listaM3);
		agregarListaMaterias(a22, listaM3);
		agregarListaMaterias(a23, listaM3);
	
		c1.agregarAlumno(a1);
		c1.agregarAlumno(a2);
		c1.agregarAlumno(a3);
		c1.agregarAlumno(a4);
		c1.agregarAlumno(a5);
		c1.agregarAlumno(a6);
		c1.agregarAlumno(a7);
		
		c2.agregarAlumno(a1);
		c2.agregarAlumno(a2);
		c2.agregarAlumno(a3);
		c2.agregarAlumno(a4);
		c2.agregarAlumno(a5);
		c2.agregarAlumno(a6);
		c2.agregarAlumno(a7);
		c2.agregarAlumno(a8);
		c2.agregarAlumno(a8);
		c2.agregarAlumno(a9);
		c2.agregarAlumno(a10);
		c2.agregarAlumno(a11);
		c2.agregarAlumno(a12);
		c2.agregarAlumno(a13);
		c2.agregarAlumno(a14);
		c2.agregarAlumno(a15);
		c2.agregarAlumno(a16);
		c2.agregarAlumno(a17);
		c2.agregarAlumno(a18);
		c2.agregarAlumno(a19);
		c2.agregarAlumno(a20);
		c2.agregarAlumno(a21);
		c2.agregarAlumno(a22);
		c2.agregarAlumno(a23);
		
		c3.agregarAlumno(a20);
		c3.agregarAlumno(a21);
		
		ort.agregarCarrera(c1);
		ort.agregarCarrera(c2);
		ort.agregarCarrera(c3);
		
		ort.imprimirListaCandidatos("Musicoterapia", 7); //CARRERA NO ENCONTRADA
		ort.imprimirListaCandidatos("Lic. Psicologia", 7);//LISTA VACIA
		ort.imprimirListaCandidatos("Analista de Sistemas", 8);//LISTA CORRECTA SOLO CON LOS QUE CUMPLEN
		ort.imprimirListaCandidatos("Produccion Musical", 4);// FALTA TESTEAR EL TOPE DE 20 ALUMNOS POR LISTA
		
		
		
	}
	
	public static void agregarListaMaterias(Alumno a, ArrayList<Materia> materias) {
		a.agregarListaMaterias(materias);
	}

}