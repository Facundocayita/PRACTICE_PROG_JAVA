package ej7;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Producto {

	private String nombre;
	private double precio;
	private int cantidadStock;
	
	public Producto(String nombre, double precio, int cantidadStock) {
		setNombre(nombre);
		setPrecio(precio);
		setCantidadStock(cantidadStock);
	}

	private void setNombre(String nombre) {
		this.nombre = nombre;
	}

	private void setPrecio(double precio) {
		this.precio = precio;
	}

	private void setCantidadStock(int cantidadStock) {
		this.cantidadStock = cantidadStock;
	}

	public String getNombre() {

		return this.nombre;
	}

	public int getCantidadStock() {
		return cantidadStock;
	}

	public void restarStock(int cantProd) {
		this.cantidadStock -= cantProd;
		
	}
	
	
	

}