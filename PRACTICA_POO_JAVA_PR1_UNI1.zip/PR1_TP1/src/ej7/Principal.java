package ej7;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Principal {

	public static void main(String[] args) {
		
		Portal  portal = new Portal();
		
		Producto prod1 = new Producto("Go-Pro", 130.000, 5);
		Producto prod2= new Producto("CPU", 270.000, 10);
		Producto prod3= new Producto("Macbook", 550.000, 8);
		Producto prod4 = new Producto("CamaraWeb", 3400.000, 6);
		Producto prod5 = new Producto("Teclado", 115.000, 22);
		Producto prod6 = new Producto("Mouse", 20.000, 9);
		Producto prod7 = new Producto("Microfono", 45.000, 30);
		Producto prod8 = new Producto("Longboard", 45.000, 30); // PRODUCTO NO AGREGADO AL STOCK

		
		
		Cliente cliente1 = new Cliente("Pedro", "Fernandez", "Agrelo 655", "j.fernandez@gmail.com", "114455-6677");
		Cliente cliente2 = new Cliente("Carla", "Martinez", "Corrientes 123", "c.martinez@gmail.com", "114455-6678");
		Cliente cliente3 = new Cliente("Melina", "Gutierrez", "Gascón 876", "m.gutierrez@gmail.com", "114455-6679");
		Cliente cliente4 = new Cliente("Lucas", "Alvarez", "Lambare 66", "l.alvarez@gmail.com", "114455-6671");
		Cliente cliente5 = new Cliente("Juan", "Cimini", "Otamendi 934", "j.cimini@gmail.com", "114455-6672");
		
		portal.agregarProducto(prod1);
		portal.agregarProducto(prod2);
		portal.agregarProducto(prod3);
		portal.agregarProducto(prod4);
		portal.agregarProducto(prod5);
		portal.agregarProducto(prod6);
		portal.agregarProducto(prod7);
		
		portal.agregarCliente(cliente1);
		portal.agregarCliente(cliente2);
		portal.agregarCliente(cliente3);
		portal.agregarCliente(cliente4);
		portal.agregarCliente(cliente5);
		
		Item item1 = new Item(2, prod7);
		Item item2 = new Item(6, prod6);
		Item item3 = new Item(11, prod5);
		Item item4 = new Item(22, prod4);//NO HAY SUFICIENTE EN STOCK
		Item item5 = new Item(11, prod3);
		Item item6 = new Item(11, prod2);
		Item item7 = new Item(11, prod1);
		
		Pedido pedido1 = new Pedido("22/03/2024", EstadoPedido.PENDIENTE);
		Pedido pedido2 = new Pedido("23/03/2024", EstadoPedido.PENDIENTE);
		
		pedido1.agregarItem(item1);
		pedido1.agregarItem(item2);
		pedido1.agregarItem(item3);
		pedido1.agregarItem(item4);
		
		pedido2.agregarItem(item5);
		pedido2.agregarItem(item6);
		pedido2.agregarItem(item7);
		
		cliente1.agregarPedidoPend(pedido1);
		
		cliente1.imprimirPedidoPendiente();
		
		portal.procesarPedido(cliente1);// PROCESO EL PEDIDO 1
		portal.confirmarPedido(cliente1);// CONFIRMO PEDIDO 1
		
		cliente1.agregarPedidoPend(pedido2);//AGREGO EL PEDIDO 2
		
		System.out.println("IMPRIMO PEDIDO PENDIENTE 2");
		cliente1.imprimirPedidoPendiente();
		cliente1.imprimirHistorialPedidos();
		
		
	}

}