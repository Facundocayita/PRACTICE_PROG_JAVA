package ej7;

import java.util.ArrayList;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Cliente {

	private String nombre;
	private String apellido;
	private String direccion;
	private String email;
	private String telefono;
	private ArrayList<Pedido> historialPedidos;
	private Pedido pedidoPend;

	public Cliente(String nombre, String apellido, String direccion, String email, String telefono) {
		this.historialPedidos = new ArrayList<Pedido>();
		setNombre(nombre);
		setApellido(apellido);
		setDireccion(direccion);
		setEmail(email);
		setTelefono(telefono);
		pedidoPend = null;
	}
	
	

	private void setNombre(String nombre) {
		this.nombre = nombre;
	}



	private void setApellido(String apellido) {
		this.apellido = apellido;
	}



	private void setDireccion(String direccion) {
		this.direccion = direccion;
	}



	private void setEmail(String email) {
		this.email = email;
	}



	private void setTelefono(String telefono) {
		this.telefono = telefono;
	}



	public Pedido getPedidoPendiente() {
		return this.pedidoPend;
	}

	public void confirmarPedido() {
		pedidoPend.cambiarEstado(EstadoPedido.CONFIRMADO);
		this.historialPedidos.add(pedidoPend);
		pedidoPend = null;
	}



	public void agregarPedidoPend(Pedido pedido) {
		if(pedido.getEstado().equals(EstadoPedido.PENDIENTE) && this.pedidoPend == null) {
			this.pedidoPend = pedido;
		}
		
	}



	public void imprimirPedidoPendiente() {
		System.out.println("Cliente: "+this.nombre+" "+this.apellido);
		this.pedidoPend.imprimirItems();
		
	}



	public void imprimirHistorialPedidos() {
		System.out.println("Cliente: "+this.nombre+" "+this.apellido);
		System.out.println("HISTORIAL DE PEDIDOS");
		System.out.println(historialPedidos.size());
		for(Pedido p: this.historialPedidos) {
			p.imprimirItems();
		}
		
		
	}

}