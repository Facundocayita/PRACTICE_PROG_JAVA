package ej7;

import java.util.ArrayList;

/**
 * Código generado por la app UXFtoJava by Charly Cimino
 * @see https://github.com/CharlyCimino/uxf-to-java
 */
public class Portal {

	private ArrayList<Cliente> clientes;
	private ArrayList<Producto> productos;

	public Portal() {
		this.clientes =  new ArrayList<Cliente>();
		this.productos = new ArrayList<Producto>();
	}

	public void confirmarPedido(Cliente cliente) {
		
		procesarPedido(cliente);
		sacarProductosDeStock(cliente.getPedidoPendiente());
		cliente.confirmarPedido();
	}

	private void sacarProductosDeStock(Pedido pedidoPendiente) {
		int i = 0;
		Producto productoABuscar = null;
		int cantProd = 0;

		while(i < pedidoPendiente.itemsSize()) {
			productoABuscar = pedidoPendiente.getProdDeItem(i);
			cantProd = pedidoPendiente.getCantProdDeItem(i);
			procesarProdDeStock(productoABuscar,cantProd);
			i++;
		}

	}

	private void procesarProdDeStock(Producto productoABuscar, int cantProd) {
		int i = 0;
		
		while(i < this.productos.size()) {
			if(this.productos.get(i).equals(productoABuscar)) {
				this.productos.get(i).restarStock(cantProd);
			}
			i++;
		}

	}

	public ArrayList<Producto> procesarPedido(Cliente cliente) {
		Pedido pendiente =  cliente.getPedidoPendiente();
		return this.verfificarStockProductos(pendiente);
	}

	private ArrayList<Producto> verfificarStockProductos(Pedido pendiente) {
		ArrayList<Producto> prodSinStock = new ArrayList<Producto>();
		int i = 0;
		Producto productoABuscar = null;
		int cantProd = 0;

		while(i < pendiente.itemsSize()) {
			productoABuscar = pendiente.getProdDeItem(i);
			cantProd = pendiente.getCantProdDeItem(i);
			if(!this.hayStock(productoABuscar,cantProd)){
				prodSinStock.add(productoABuscar);
				pendiente.eliminarItem(i);
			}
			i++;
		}

		return prodSinStock;
	}

	private boolean hayStock(Producto productoABuscar, int cantProd) {
		boolean hayStock = false;
		int i = 0;

		while(i < this.productos.size() && hayStock == false) {

			if(this.productos.get(i) == productoABuscar && this.productos.get(i).getCantidadStock()>=cantProd) {
				hayStock = true;
			}
			i++;

		}

		return hayStock;
	}

	public void agregarProducto(Producto prod) {
		if(!this.productos.contains(prod)) {
			this.productos.add(prod);
		}
		
	}

	public void agregarCliente(Cliente cliente) {
		if(!this.clientes.contains(cliente)) {
			this.clientes.add(cliente);
		}
		
	}

}