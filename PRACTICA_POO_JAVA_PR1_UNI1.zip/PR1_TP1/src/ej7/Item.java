package ej7;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Item {

	private int cantidad;
	private Producto producto;
	
	public Item(int cantidad, Producto producto) {
		setCantidad(cantidad);
		setProducto(producto);
		
	}

	private void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	private void setProducto(Producto producto) {
		this.producto = producto;
	}

	public int getCantidad() {
		return cantidad;
	}

	public Producto getProducto() {
		return producto;
	}

	@Override
	public String toString() {
		return "Item [cantidad=" + cantidad + ", producto=" + producto.getNombre() + "]";
	}
	
	
	
	
	
	

}