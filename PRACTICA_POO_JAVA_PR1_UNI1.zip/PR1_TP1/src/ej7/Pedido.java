package ej7;

import java.util.ArrayList;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Pedido {

	private String fechaHora;
	private ArrayList<Item> items;
	private EstadoPedido estado;
	
	public Pedido(String fechaHora, EstadoPedido estado) {
		items = new ArrayList<Item>();
		setFechaHora(fechaHora);
		setEstado(estado);
	}

	private void setFechaHora(String fechaHora) {
		this.fechaHora = fechaHora;
	}

	private void setEstado(EstadoPedido estado) {
		this.estado = estado;
	}

	public int itemsSize() {
		return this.items.size();
	}

	public Producto getProdDeItem(int i) {
		return this.items.get(i).getProducto();
	}

	public int getCantProdDeItem(int i) {
		return this.items.get(i).getCantidad();
	}

	public void eliminarItem(int i) {
		this.items.remove(i);
		
	}

	public void cambiarEstado(EstadoPedido confirmado) {
		setEstado(confirmado);
		
	}

	public void agregarItem(Item item) {
		if(!this.items.contains(item)) {
			this.items.add(item);
		}
		
	}

	public EstadoPedido getEstado() {
		return this.estado;
	}

	public void imprimirItems() {
		for(Item i: this.items) {
			System.out.println(i.toString());
		}
		
		
		
	}

	@Override
	public String toString() {
		return "Pedido [fechaHora=" + fechaHora + ", estado=" + estado + "]";
	}

	
	

}