package ej7;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public enum EstadoPedido {

	PENDIENTE,
	CONFIRMADO,
	EN_CAMINO,
	ENTREGADO;

}