package ej5;

import java.util.ArrayList;
import java.util.concurrent.ArrayBlockingQueue;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Mesa {

	private int numero;
	private ArrayList<Persona> votantes;
	private Persona presidente;

	public Mesa(int numero) {
		setNumero(numero);
		votantes =  new ArrayList<Persona>();
	}
	
	

	private void setNumero(int numero) {
		this.numero = numero;
	}



	public void designarPresidente(Persona persona) {
		this.presidente = persona;
		if(!votantes.contains(persona)) {
			votantes.add(persona);
		}
	}

	public ArrayList<Resumen> obtenerInforme() {
		ArrayList<Resumen> informeMesa =  new ArrayList<Resumen>();
		Resumen r = null;
		
		//CHEQUEAR POSIBLE ERROR EN r = new Resumen(), capaz tira error y tengo que poner r = null para volver a crear el r
		for(Persona votante: this.votantes) {
			r = new Resumen(this.numero, this.votantes.indexOf(votante), votante.getDni(), votante.getNombre()+" "+votante.getApellido());
			informeMesa.add(r);
			
		}
		return informeMesa;
	}
	


	public int getNumero() {
		return numero;
	}



	public Persona buscarPersona(Persona persona) {
		Persona encontrada = null;
		int i = 0;
		
		while(i < this.votantes.size() && encontrada == null) {
			if (this.votantes.get(i).equals(persona)) {
				encontrada = this.votantes.get(i);
			}
			i++;
		}
		return encontrada;
	}



	public void eliminar(Persona persona) {
		this.votantes.remove(persona);
		
	}



	public void eliminarPresidenteDeMesa(Persona persona) {
		if(this.chequearEsPresidenteDeMesa(persona)) {
			this.presidente =  null;
		}
		
	}



	private boolean chequearEsPresidenteDeMesa(Persona persona) {
				return this.presidente.equals(persona);
	}



	public void agregarVotante(Persona persona) {
		this.votantes.add(persona);
		
	}
	
	public String devolverPresidente() {
		return this.presidente.toString();	}

}