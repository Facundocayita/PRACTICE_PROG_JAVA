package ej5;

/**
 * Código generado por la app UXFtoJava by Charly Cimino
 * @see https://github.com/CharlyCimino/uxf-to-java
 */
public class Domicilio {

	private String calle;
	private int codigoPostal;
	private String provincia;


	public Domicilio(String calle, int codigoPostal, String provincia) {
		setCalle(calle);
		setCodigoPostal(codigoPostal);
		setProvincia(provincia);
	}


	private void setCalle(String calle) {
		this.calle = calle;
	}


	private void setCodigoPostal(int codigoPostal) {
		this.codigoPostal = codigoPostal;
	}


	private void setProvincia(String provincia) {
		this.provincia = provincia;
	}



}