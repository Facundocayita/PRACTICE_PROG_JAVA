package ej5;

import java.util.ArrayList;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Padron {

	private ArrayList<Escuela> escuelas;
	
	

	public Padron() {
		this.escuelas =  new ArrayList<Escuela>();
	}



	public void mostrarDatosInformeEscuela(String nombreEscuela) {
		Escuela escuela = buscarEscuela(nombreEscuela);
		ArrayList<Resumen> informeEscuela =  new ArrayList<Resumen>();
		
		if(escuela != null) {
			informeEscuela = escuela.obtenerInforme();
			System.out.println("Informe escuela: "+escuela.getNombre());
			for(Resumen r: informeEscuela) {
				System.out.println(r.toString());
			}
		}else {
			System.out.println("Escuela no esta en padron");
		}
		
		
	}



	private Escuela buscarEscuela(String nombreEscuela) {
		Escuela encontrada = null;
		int i = 0;
		
		while(i < this.escuelas.size() && encontrada == null) {
			if(this.escuelas.get(i).getNombre().equals(nombreEscuela)) {
				encontrada =  this.escuelas.get(i);
			}
			i++;
			
		}
		
		return encontrada;
	}



	public void agregarEscuela(Escuela e) {
		this.escuelas.add(e);
		
	}

}