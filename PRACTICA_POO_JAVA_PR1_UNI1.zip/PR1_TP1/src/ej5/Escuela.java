package ej5;

import java.util.ArrayList;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Escuela {

	private String nombre;
	private Domicilio domicilio;
	private ArrayList<Mesa> mesas;

	public Escuela(String nombre, Domicilio domicilio) {
		setNombre(nombre);
		setDomicilio(domicilio);
		mesas = new ArrayList<Mesa>();
		
	}
	
	

	private void setNombre(String nombre) {
		this.nombre = nombre;
	}



	private void setDomicilio(Domicilio domicilio) {
		this.domicilio = domicilio;
	}
	
	



	public String getNombre() {
		return nombre;
	}



	public void designarPresidenteDeMesa(Mesa mesa, Persona persona) {
		chequearPersonaCargadaEnOtraMesa(persona);
		mesa.designarPresidente(persona);
	}

	private void chequearPersonaCargadaEnOtraMesa(Persona persona) {
		Persona encontrada = null;
		int i = 0;
		
		while(i < this.mesas.size() && encontrada == null) {
			
			encontrada = this.mesas.get(i).buscarPersona(persona);
			i++;
		}
		
		if(encontrada != null) {
		
			i--;
			this.mesas.get(i).eliminar(persona);
			this.mesas.get(i).eliminarPresidenteDeMesa(persona);
		}
		
	}



	public ArrayList<Resumen> obtenerInforme() {
		ArrayList<Resumen> informeEscuelaTotal = new ArrayList<Resumen>();
		for(Mesa m: this.mesas) {
			informeEscuelaTotal.addAll(m.obtenerInforme());
		}
		
		return informeEscuelaTotal;
	}



	public void agregarMesa(Mesa m) {
		this.mesas.add(m);
		
	}

}