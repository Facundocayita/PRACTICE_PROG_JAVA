package ej5;

import java.util.ArrayList;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Persona {

	private String nombre;
	private String apellido;
	private String dni;
	private String fechaNacimiento;
	private Genero genero;
	private Domicilio domicilio;
	

	public Persona(String nombre, String apellido, String dni, String fechaNacimiento, Genero genero, Domicilio domicilio) {
		setNombre(nombre);
		setApellido(apellido);
		setDni(dni);
		setFechaNacimiento(fechaNacimiento);
		setGenero(genero);
		setDomicilio(domicilio);
	}


	private void setNombre(String nombre) {
		this.nombre = nombre;
	}


	private void setApellido(String apellido) {
		this.apellido = apellido;
	}


	private void setDni(String dni) {
		this.dni = dni;
	}


	private void setFechaNacimiento(String fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}


	private void setGenero(Genero genero) {
		this.genero = genero;
	}


	private void setDomicilio(Domicilio domicilio) {
		this.domicilio = domicilio;
	}


	public String getNombre() {
		return nombre;
	}


	public String getApellido() {
		return apellido;
	}


	public String getDni() {
		return dni;
	}


	@Override
	public String toString() {
		return "[nombre=" + nombre + ", apellido=" + apellido + ", dni=" + dni + ", fechaNacimiento="
				+ fechaNacimiento + ", genero=" + genero + "]";
	}
	
	
	

}