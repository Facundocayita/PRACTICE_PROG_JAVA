package ej5;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Principal {

	public static void main(String[] args) {
		Domicilio domicilio1 = new Domicilio("Rivadavia 5800", 1406, "Buenos Aires");
		Domicilio domicilio2 = new Domicilio("Yerbal 160", 1405, "Buenos Aires");
		
		Persona p1 = new Persona("Juan", "Perez", "12345678", "01/01/1900", Genero.MASCULINO, domicilio1);
		Persona p2 = new Persona("Pablo", "Alvarez", "12345677", "01/01/1900", Genero.MASCULINO, domicilio1);
		Persona p3 = new Persona("Mariela", "Rodriguez", "12345676", "01/01/1900", Genero.FEMENINO, domicilio1);
		Persona p4 = new Persona("Enrique", "Ayala", "12345675", "01/01/1900", Genero.MASCULINO, domicilio1);
		Persona p5 = new Persona("Sofia", "Montes", "12345674", "01/01/1900", Genero.OTRO, domicilio1);
		Persona p6 = new Persona("Carla", "Gavilan", "12345673", "01/01/1900", Genero.FEMENINO, domicilio1);
		Persona p7 = new Persona("Carolina", "Perez", "12345672", "01/01/1900", Genero.FEMENINO, domicilio1);
		Persona p8 = new Persona("Pedro", "Mayora", "12345671", "01/01/1900", Genero.OTRO, domicilio1);
		
		
		Mesa m1 = new Mesa(1);
		Mesa m2 = new Mesa(2);
		Mesa m3 = new Mesa(3);
		
		m1.designarPresidente(p1);
		m1.agregarVotante(p2);
		m1.agregarVotante(p3);
		
		m2.designarPresidente(p4);
		m2.agregarVotante(p5);
		m2.agregarVotante(p6);
		
		m3.designarPresidente(p7);
		m3.agregarVotante(p8);
		
		Escuela e1 = new Escuela("Angeles Custodios", domicilio2);
		Escuela e2 = new Escuela("Norberto Piñero", domicilio2);
		
		e1.agregarMesa(m1);
		e1.agregarMesa(m2);
		e2.agregarMesa(m3);
		
		Padron padron = new Padron();
		
		padron.agregarEscuela(e1);
		padron.agregarEscuela(e2);
		
		padron.mostrarDatosInformeEscuela("Angeles Custodios");
		System.out.println("-----------------------------");
		padron.mostrarDatosInformeEscuela("ORT");
		System.out.println("-----------------------------");
		padron.mostrarDatosInformeEscuela("Norberto Piñero");
		System.out.println("-----------------------------");
		System.out.println("PRUEBAS PRESIDENTE MESA");
		System.out.println("PRESIDENTE DE MESA "+m1.getNumero());
		System.out.println(m1.devolverPresidente());
		System.out.println("-cambio presidente de mesa-");
		m1.designarPresidente(p8);
		System.out.println(m1.devolverPresidente());
		padron.mostrarDatosInformeEscuela("Angeles Custodios");
		


	}

}