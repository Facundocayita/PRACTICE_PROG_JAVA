package ej5;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public enum Genero {

	MASCULINO,
	FEMENINO,
	OTRO;

}