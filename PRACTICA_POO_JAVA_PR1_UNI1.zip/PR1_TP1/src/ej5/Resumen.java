package ej5;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Resumen {

	private int numeroMesa;
	private int numeroOrden;
	private String dniPersona;
	private String nombreCompleto;

	public Resumen(int numeroMesa, int numeroOrden, String dniPersona, String nombreCompleto) {
		setNumeroMesa(numeroMesa);
		setNumeroOrden(numeroOrden);
		setDniPersona(dniPersona);
		setNombreCompleto(nombreCompleto);
	}

	private void setNumeroMesa(int numeroMesa) {
		this.numeroMesa = numeroMesa;
	}

	private void setNumeroOrden(int numeroOrden) {
		this.numeroOrden = numeroOrden;
	}

	private void setDniPersona(String dniPersona) {
		this.dniPersona = dniPersona;
	}

	private void setNombreCompleto(String nombreCompleto) {
		this.nombreCompleto = nombreCompleto;
	}

	@Override
	public String toString() {
		return "[numeroMesa=" + numeroMesa + ", numeroOrden=" + numeroOrden + ", dniPersona=" + dniPersona
				+ ", nombreCompleto=" + nombreCompleto + "]";
	}
	
	
	
	

}