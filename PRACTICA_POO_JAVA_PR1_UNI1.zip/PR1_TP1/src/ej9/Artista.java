package ej9;

import java.util.ArrayList;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Artista {

	private String id;
	private String nombre;
	private static final int CANT_CANCIONES = 5;
	private static final double PORC_PARA_SER_DESTACADO = 0.5;
	private ArrayList<Cancion> canciones;

	public Artista(String id, String nombre) {
		setId(id);
		setNombre(nombre);
		this.canciones = new ArrayList<Cancion>();
	}
	

	private void setId(String id) {
		this.id = id;
	}


	private void setNombre(String nombre) {
		this.nombre = nombre;
	}



	public void agregarCancion(Cancion cancion) {
		if(buscarCancion(cancion) == null) {
			this.canciones.add(cancion);
		}
	}

	private Cancion buscarCancion(Cancion cancion) {
		Cancion encontrada = null;
		int i = 0;
		while(i < this.canciones.size() && encontrada == null) {
			if(this.canciones.get(i).equals(cancion)) {
				encontrada = cancion;
			}else {
				i++;
			}
		}
		return encontrada;
	}


	
	private int totalSegCanciones() {
		int duracionTotal = 0;
		for(Cancion c: this.canciones) {
			duracionTotal += c.getDuracion();
		}
		return duracionTotal;
	}
	
	public void mostrarDuracionPromedio() {
		int totalSegundos = totalSegCanciones()/this.canciones.size();
		
		int minutos = totalSegundos / 60;
		int segundos = totalSegundos % this.canciones.size();; // CREO QUE ASI SE SACA EL RESTO DE UNA DIVSION, CHEQUEAR
		
		System.out.println("Duracion promedio de canciones:"+minutos+" minutos, "+segundos+" segundos.");

	}

	public boolean esFanDestacado(Usuario usuario) {
		boolean esDestacado = false;
	
		if(likesUsuario(usuario) >= (this.canciones.size()* Artista.PORC_PARA_SER_DESTACADO)) {
			esDestacado = true;
		}
		
		return esDestacado;
	}

	private double likesUsuario(Usuario usuario) {
		double likes = 0;
		
		for(Cancion c: this.canciones) {
			if(c.buscarUsuario(usuario) != null) {
				likes++;
			}
		}
		return likes;
	}


	public ArrayList<Cancion> primeras5Canciones() {
		ArrayList<Cancion> primeras5Canciones = new ArrayList<Cancion>();
		if(this.canciones.size() < CANT_CANCIONES) {
			primeras5Canciones =  this.canciones;
		}else {
			int i = 0;
			while(i <  CANT_CANCIONES) {
				primeras5Canciones.add(this.canciones.get(i));
				i++;
			}
	
		}
		return primeras5Canciones;
	}
	
	
	public void imprimirPrimeras5Canciones() {
		ArrayList<Cancion> primeras5Canciones = primeras5Canciones();
		
		for(Cancion c: primeras5Canciones) {
			System.out.println(c.toString());
		}
	}


	public void borrarUsuario(Usuario usuario) {
		for(Cancion c: this.canciones) {
				c.borrarUsuario(usuario);
		}
	}


	public boolean mismoNombre(String nombreArtista) {

		return this.nombre.equals(nombreArtista);
	}


	public void darLikeCancion(Usuario uEncontrado, String nombreCancion) {
		Cancion c = buscarCancion(nombreCancion);
		c.darLike(uEncontrado);
		
	}


	private Cancion buscarCancion(String nombreCancion) {
		Cancion encontrado = null;
		int i = 0;
		
		while(i < this.canciones.size() && encontrado == null) {
			if(this.canciones.get(i).mismoNombre(nombreCancion)) {
				encontrado = this.canciones.get(i);
			}else {
				i++;
			}
		}
		return encontrado;
	}

}