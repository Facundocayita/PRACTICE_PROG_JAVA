package ej9;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Principal {

	public static void main(String[] args) {
		ORTify ortify = new ORTify();
		
		Artista a1 = new Artista("01", "Nirvana");
		Artista a2 = new Artista("02", "Pearl Jam");
		Artista a3 = new Artista("03", "Alice in chains");
		Artista a4 = new Artista("04", "Soundgarden");
		
		ortify.agregarArtista(a1);
		ortify.agregarArtista(a2);
		ortify.agregarArtista(a3);
		ortify.agregarArtista(a4);
		
		Usuario u1 = new Usuario("u1", "Pedro Alvarez", EstadoUsuario.HABILITADO);
		Usuario u2 = new Usuario("u2", "Juan Ascho", EstadoUsuario.PRUEBA_GRATIS);
		Usuario u3 = new Usuario("u3", "Maria Rodriguez", EstadoUsuario.PRUEBA_GRATIS);
		Usuario u4 = new Usuario("u4", "Liliana Fernandez", EstadoUsuario.HABILITADO);
		
		ortify.agregarUsuario(u1);
		ortify.agregarUsuario(u2);
		ortify.agregarUsuario(u3);
		ortify.agregarUsuario(u4);
		
		Cancion c1 = new Cancion("c1", "Drain you", 220);
		Cancion c2 = new Cancion("c2", "Molly´s lips", 94);
		Cancion c3 = new Cancion("c3", "Floyd the barber", 287);
		Cancion c4 = new Cancion("c4", "School", 345);
		
		Cancion c5 = new Cancion("c5", "Heart shaped-box", 342);
		Cancion c6 = new Cancion("c6", "In bloom", 235);
		Cancion c7 = new Cancion("c7", "Blew", 303);
		
		
		a1.agregarCancion(c1);
		a1.agregarCancion(c2);
		a1.agregarCancion(c3);
		a1.agregarCancion(c4);
		
		a1.imprimirPrimeras5Canciones();// IMPRIME LAS 4 CARGADAS
		
		a1.agregarCancion(c5);
		a1.agregarCancion(c6);
		a1.agregarCancion(c7);
		
		System.out.println("IMPRIME NUEVAMENTE LAS 5 CANCIONES....");
		a1.imprimirPrimeras5Canciones();// OK, IMPRIME LAS PRIMERAS 5
		a1.mostrarDuracionPromedio();//CREO ANDA BIEN
		
		ortify.darLikeCancion("Pedro Alvarez", "Nirvana", "Drain you");
		ortify.darLikeCancion("Pedro Alvarez", "Nirvana", "Molly´s lips");
		ortify.darLikeCancion("Pedro Alvarez", "Nirvana", "Floyd the barber");
		ortify.darLikeCancion("Pedro Alvarez", "Nirvana", "School");
		
		System.out.println(a1.esFanDestacado(u1));// TRUE
		System.out.println(a1.esFanDestacado(u2));// FALSE
		
	
		ortify.listarUsuario();// 4 USUARIOS TOTAL
		
		ortify.darLikeCancion("Juan Ascho", "Nirvana", "Drain you");
		ortify.darLikeCancion("Maria Rodriguez", "Nirvana", "Drain you");
		
		c1.devolvetCantLikes();// 3 LIKES
		
		System.out.println(ortify.borrarUsuario("Juan Ascho"));// BORRADO
		ortify.listarUsuario();// 3 USUARIOS TORAL
		c1.devolvetCantLikes();// 2 LIKES
	}

}