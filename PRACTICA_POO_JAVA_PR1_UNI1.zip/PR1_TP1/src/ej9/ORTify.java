package ej9;

import java.util.ArrayList;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class ORTify {

	private ArrayList<Artista> artistas;
	private ArrayList<Usuario> usuarios;

	public ORTify() {
		this.artistas = new ArrayList<Artista>();
		this.usuarios = new ArrayList<Usuario>();
	}

	public void agregarArtista(Artista artista) {
		if(!this.artistas.contains(artista)) {
			this.artistas.add(artista);
		}
	}

	public void agregarUsuario(Usuario usuario) {
		if(!this.usuarios.contains(usuario)) {
			this.usuarios.add(usuario);
		}
	}

	public Usuario borrarUsuario(String nombreUsuario) {
		Usuario borrado = buscarUsuario(nombreUsuario);
		if(borrado != null) {
			this.usuarios.remove(borrado);
			for(Artista a: this.artistas) {
				a.borrarUsuario(borrado);
			}
		}
		
		
		return borrado;
	}

	private Usuario buscarUsuario(String nombreUsuario) {
		Usuario borrado = null;
		int i = 0;
		
		while(i < this.usuarios.size() && borrado == null) {
			if(this.usuarios.get(i).mismoNombre(nombreUsuario)) {
				borrado = this.usuarios.get(i);
			}else {
				i++;
			}
		}
		return borrado;
	}
	
	public void darLikeCancion(String nombreUsuario, String nombreArtista, String nombreCancion) {
		Usuario uEncontrado =  buscarUsuario(nombreUsuario);
		
		if(uEncontrado != null) {
			Artista aEncontrado = buscarArtista(nombreArtista);
			aEncontrado.darLikeCancion(uEncontrado, nombreCancion);
		}
	}

	private Artista buscarArtista(String nombreArtista) {
		Artista encontrado = null;
		int i = 0;
		
		while(i < this.artistas.size() && encontrado == null) {
			if(this.artistas.get(i).mismoNombre(nombreArtista)) {
				encontrado = this.artistas.get(i);
			}else {
				i++;
			}
		}
		return encontrado;
		
	}
	
	public void listarUsuario() {
		
		System.out.println("LISTADO DE USUARIOS");
		for(Usuario u: this.usuarios) {
			System.out.println(u.toString());
		}
	}

}