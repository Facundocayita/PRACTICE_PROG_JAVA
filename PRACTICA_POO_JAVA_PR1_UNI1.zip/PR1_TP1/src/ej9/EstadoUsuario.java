package ej9;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public enum EstadoUsuario {

	HABILITADO,
	PRUEBA_GRATIS,
	SUSPENDIDO;

}