package ej9;

import java.util.ArrayList;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Cancion {

	private String id;
	private String nombre;
	private int duracionSegundos;
	private ArrayList<Usuario> usuariosLikearon;

	public Cancion(String id, String nombre, int duracion) {
		setId(id);
		setNombre(nombre);
		setDuracionSegundos(duracion);
		this.usuariosLikearon =  new ArrayList<Usuario>();
	}

	private void setId(String id) {
		this.id = id;
	}

	private void setNombre(String nombre) {
		this.nombre = nombre;
	}

	private void setDuracionSegundos(int duracionSegundos) {
		this.duracionSegundos = duracionSegundos;
	}

	public int getDuracion() {

		return duracionSegundos;
	}

	public Usuario buscarUsuario(Usuario usuario) {
		Usuario encontrado = null;
		if(this.usuariosLikearon.contains(usuario)) {
			encontrado = usuario;
		}
		return encontrado;
	}

	public void borrarUsuario(Usuario usuario) {
		if(this.usuariosLikearon.contains(usuario)) {
			this.usuariosLikearon.remove(usuario);
		}
		
	}

	@Override
	public String toString() {
		return "Cancion [id=" + id + ", nombre=" + nombre + ", duracionSegundos=" + duracionSegundos + "]";
	}

	public boolean mismoNombre(String nombreCancion) {
		return this.nombre.equals(nombreCancion);
	}

	public void darLike(Usuario uEncontrado) {
		if(!this.usuariosLikearon.contains(uEncontrado)) {
			this.usuariosLikearon.add(uEncontrado);
		}
		
	}
	
	public void devolvetCantLikes() {
		System.out.println("Cancion: "+this.nombre+". Likes: "+this.usuariosLikearon.size());
		}


}