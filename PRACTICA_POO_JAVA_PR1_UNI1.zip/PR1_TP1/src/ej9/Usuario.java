package ej9;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Usuario {

	private String id;
	private String nombre;
	private EstadoUsuario estado;

	public Usuario(String id, String nombre, EstadoUsuario estado) {
		setId(id);
		setNombre(nombre);
		setEstado(estado);
		
	}

	private void setId(String id) {
		this.id = id;
	}

	private void setNombre(String nombre) {
		this.nombre = nombre;
	}

	private void setEstado(EstadoUsuario estado) {
		this.estado = estado;
	}

	public boolean mismoNombre(String nombreUsuario) {
		
		return this.nombre.equals(nombreUsuario);
	}

	@Override
	public String toString() {
		return "Usuario [id=" + id + ", nombre=" + nombre + ", estado=" + estado + "]";
	}
	
	

}