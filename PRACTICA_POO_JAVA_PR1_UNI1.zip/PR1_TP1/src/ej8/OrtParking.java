package ej8;

import java.util.ArrayList;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class OrtParking {

	private ArrayList<Garage> garages;
	
	

	public OrtParking() {
		this.garages  = new ArrayList<Garage>();
	}


	public ArrayList<EstadoGarage> obtenerInformeEstadoGarajes() {
		ArrayList<EstadoGarage> listaInformeGarages = new ArrayList<EstadoGarage>();
		
		for(Garage g: this.garages) {
			listaInformeGarages.add(g.devolverEstado());
		}
		
		return listaInformeGarages;
	}
	
	
	public void imprimirInformeEstadoGarajes() {
		ArrayList<EstadoGarage> informeGarages = obtenerInformeEstadoGarajes();
		
		for(EstadoGarage estadoGarage:informeGarages ) {
			estadoGarage.imprimirDatos();
		}	
		
	}
	
	
	public void mostrarVehiculosSinLlave() {
		for(Garage g: this.garages) {
			g.mostrarVehiculosSinLlave();
		}
		
	}


	public void agregarGarage(Garage g1) {
		if(!this.garages.contains(g1)) {
			this.garages.add(g1);
		}
		
	}

}