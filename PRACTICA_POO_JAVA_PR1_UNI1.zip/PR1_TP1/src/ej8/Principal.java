package ej8;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Principal {

	public static void main(String[] args) {
		OrtParking ortParking = new OrtParking();
		
		Garage g1 = new Garage("A-1");
		Garage g2 = new Garage("A-2");
		Garage g3 = new Garage("A-3");
		
		ortParking.agregarGarage(g1);
		ortParking.agregarGarage(g2);
		ortParking.agregarGarage(g3);
		
		Vehiculo v1 = new Vehiculo("AFD-111", 2);
		Vehiculo v2 = new Vehiculo("AFD-112", 4);
		Vehiculo v3 = new Vehiculo("AFD-113", 1);
		
		
		
		Persona p1 = new Persona("Diego Perez", "123456781");
		Persona p2 = new Persona("Pablo Alvarez", "123456782");
		
		v1.agregarPersona(p1);
		
		g1.agregarVehiculoARegistro(v1);
		g1.agregarVehiculoARegistro(v2);
		g1.agregarVehiculoARegistro(v3);
		
		g2.agregarVehiculoARegistro(v1);
		g2.agregarVehiculoARegistro(v2);
		g2.agregarVehiculoARegistro(v3);
		
		g3.agregarVehiculoARegistro(v1);
		g3.agregarVehiculoARegistro(v2);
		g3.agregarVehiculoARegistro(v3);
		
		
		
		System.out.println(v1.agregarPersona(p2));// AGREGADO CON EXITO
		System.out.println(v1.esAutorizada("123456782"));// DEVUELVE TRUE, ES AUTORIZADA
		System.out.println("PRUEBAS DE ESTACIONAR VEHICULOS...");
		System.out.println(g1.estacionarVehiculo("AFD-111"));// INGRESO_OK
		System.out.println(g1.estacionarVehiculo("AFD-113"));// INGRESO_OK
		System.out.println(g1.estacionarVehiculo("AFD-112"));// NO_ESTACIONA_ADEUDA
		System.out.println(g1.estacionarVehiculo("AFD-114"));// VEHICULO_NO_HABILITADO
		System.out.println(g1.estacionarVehiculo("AFD-111"));// VEHICULO_YA_ESTACIONADO
		
		System.out.println("INFORME ESTADO GARAGES----------");
		ortParking.imprimirInformeEstadoGarajes();// ANDA BIEN
		ortParking.mostrarVehiculosSinLlave();// ANDA BIEN
		
		System.out.println("IMPRIMO LLAVES DE TABLERO----------");
		
		g1.imprimirDatosTablero();		
		
	}

}