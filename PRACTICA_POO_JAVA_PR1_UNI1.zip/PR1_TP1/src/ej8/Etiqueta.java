package ej8;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Etiqueta {

	private String etiquetaPatente;

	public Etiqueta(String patente) {
		setEtiquetaPatente(patente);
	}

	private void setEtiquetaPatente(String etiquetaPatente) {
		this.etiquetaPatente = etiquetaPatente;
	}

	public String getPatente() {
	
		return this.etiquetaPatente;
	}

	public boolean mismaPatente(String patente) {
		boolean mismaPatente = false;
		
		if(this.etiquetaPatente.equals(patente)) {
			mismaPatente = true; 
		}
		return mismaPatente;
	}
	
	

}