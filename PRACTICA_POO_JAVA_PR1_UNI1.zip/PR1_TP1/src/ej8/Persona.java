package ej8;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Persona {

	private String nombre;
	private String dni;

	public Persona(String nombre, String dni) {
		setNombre(nombre);
		setDni(dni);
	}

	private void setNombre(String nombre) {
		this.nombre = nombre;
	}

	private void setDni(String dni) {
		this.dni = dni;
	}

	public boolean mismoDni(String dni) {

		return this.dni.equals(dni);
	}

	public String getDni() {
		return this.dni;
	}
	
	

}