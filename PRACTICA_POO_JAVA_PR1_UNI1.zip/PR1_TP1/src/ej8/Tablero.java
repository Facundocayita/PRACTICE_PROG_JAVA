package ej8;

import java.util.ArrayList;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Tablero {

	private ArrayList<Llave> llavesVehicEstacionados;

	public Tablero() {
		this.llavesVehicEstacionados =  new ArrayList<Llave>();
		
	}

	public Llave devolverLlave(String patente) {
		Llave encontrada = buscarLlave(patente);
		return encontrada;
	}

	private Llave buscarLlave(String patente) {
		Llave encontrada = null;
		int i = 0;
		
		while(i < this.llavesVehicEstacionados.size() && encontrada == null) {
			if (this.llavesVehicEstacionados.get(i).getPatente().equals(patente)){
				encontrada = this.llavesVehicEstacionados.get(i);
			}else {
				i++;
			}
		}
		return encontrada;
	}

	public void agregarLlave(Llave llave) {
		this.llavesVehicEstacionados.add(llave);
		
	}

	public boolean tieneLlave(String patente) {
		boolean tiene = false;
		int i = 0;
		
		while(i < this.llavesVehicEstacionados.size() && tiene == false) {
			if(this.llavesVehicEstacionados.get(i).mismaPatente(patente)) {
				tiene = true;
			}else {
				i++;
			}
		}
		return tiene;
	}

	public void imprimirLlaves() {
		for(Llave llave: this.llavesVehicEstacionados) {
			llave.imprimirEtiqueta();
		}
		
	}

}