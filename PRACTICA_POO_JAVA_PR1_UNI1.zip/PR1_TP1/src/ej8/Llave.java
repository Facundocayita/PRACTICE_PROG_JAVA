package ej8;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Llave {

	private Etiqueta etiqueta;

	public Llave(String patente) {
		Etiqueta etiqueta = new Etiqueta(patente);
		setEtiqueta(etiqueta);
	}

	private void setEtiqueta(Etiqueta etiqueta) {
		this.etiqueta = etiqueta;
	}

	public Object getPatente() {
		
		return this.etiqueta.getPatente();
	}

	public boolean mismaPatente(String patente) {
		return this.etiqueta.mismaPatente(patente);
	}

	public void imprimirEtiqueta() {
		System.out.println(this.etiqueta.getPatente());
		
	}
	
	

}