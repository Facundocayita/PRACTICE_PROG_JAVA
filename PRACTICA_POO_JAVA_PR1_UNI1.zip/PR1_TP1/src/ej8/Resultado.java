package ej8;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public enum Resultado {

	VEHICULO_NO_HABILITADO,
	VEHICULO_YA_ESTACIONADO,
	NO_ESTACIONA_ADEUDA,
	INGRESO_OK;

}