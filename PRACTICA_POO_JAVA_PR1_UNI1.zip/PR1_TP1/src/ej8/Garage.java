package ej8;

import java.util.ArrayList;

/**
 * Código generado por la app UXFtoJava by Charly Cimino
 * @see https://github.com/CharlyCimino/uxf-to-java
 */
public class Garage {

	private String id;
	private ArrayList<Vehiculo> estacionados;
	private ArrayList<Vehiculo> retirados;
	private Tablero tablero;
	private  final int LIMITE_MESES = 3;

	public Garage(String id) {
		setId(id);
		tablero =  new Tablero();
		estacionados = new ArrayList<Vehiculo>();
		retirados =  new ArrayList<Vehiculo>();
	}



	private void setId(String id) {
		this.id = id;
	}



	public Resultado estacionarVehiculo(String patente) {
		Vehiculo encontrado = buscarVehiculo(patente, this.estacionados);
		Resultado resultado = null;

		if(encontrado != null) {
			resultado = Resultado.VEHICULO_YA_ESTACIONADO;
		}else {

			encontrado = buscarVehiculo(patente, this.retirados);
			if(encontrado == null) {
				resultado = Resultado.VEHICULO_NO_HABILITADO;	
			}else {
				if(encontrado.deudor(LIMITE_MESES)) {
					resultado = Resultado.NO_ESTACIONA_ADEUDA;	
				}else {
					resultado = Resultado.INGRESO_OK;
					tablero.agregarLlave(encontrado.darLlave());
					this.estacionados.add(encontrado);
				}
			}

		}

		return resultado ;
	}

	private Vehiculo buscarVehiculo(String patente, ArrayList<Vehiculo> lista) {
		Vehiculo encontrado =  null;
		int i = 0;

		while(i < lista.size() && encontrado  == null) {

			if(lista.get(i).mismaPatente(patente)) {
				encontrado = lista.get(i);
			}else {
				i++;
			}

		}

		return encontrado;
	}



	public void mostrarVehiculosSinLlave() {
		ArrayList<Vehiculo> sinLlaves = new ArrayList<Vehiculo>();
		sinLlaves =  this.listarVehiculosSinLLave();

		System.out.println("Garage codigo: "+this.id);
		System.out.println("Vehiculos sin llave: ");
		for(Vehiculo v: sinLlaves) {
			System.out.println(v.getPatente());

		}

	}

	private ArrayList<Vehiculo> listarVehiculosSinLLave() {
		ArrayList<Vehiculo> sinLlaves =  new ArrayList<Vehiculo>();

		for(Vehiculo v :this.estacionados) {
			if(!this.tablero.tieneLlave(v.getPatente())) {
				sinLlaves.add(v);
			}
			
		}
		return sinLlaves;
	}



	public boolean esPersonaAutorizada(String dni) {
		boolean autorizada = false;
		int  i = 0;
		
		while(i < this.estacionados.size() && autorizada == false) {
			if(this.estacionados.get(i).esAutorizada(dni)) {
				autorizada = true;
			}else {
				i++;
			}
		}
		
		return autorizada;
	}



	public EstadoGarage devolverEstado() {
		EstadoGarage estado = new EstadoGarage(this.id, this.estacionados.size());
		return estado  ;
	}



	public void agregarVehiculoARegistro(Vehiculo v1) {
		if(!this.retirados.contains(v1)) {
			retirados.add(v1);
		}
		
	}



	public void imprimirDatosTablero() {
		System.out.println("Garage id: "+this.id);
		System.out.println("Llaves en tablero: ");
		tablero.imprimirLlaves();
		
	}

}