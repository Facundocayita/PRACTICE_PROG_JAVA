package ej8;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class EstadoGarage {

	private String id;
	private int cantEstacionados;

	public EstadoGarage(String id, int cantidad) {
		setId(id);
		setCantEstacionados(cantidad);
	}

	private void setId(String id) {
		this.id = id;
	}

	private void setCantEstacionados(int cantEstacionados) {
		this.cantEstacionados = cantEstacionados;
	}

	public void imprimirDatos() {
		System.out.println("Garage: "+this.id);
		System.out.println("Cant. Vehiculos Estacionados: "+this.cantEstacionados);
		
	}
	
	

}