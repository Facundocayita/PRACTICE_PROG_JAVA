package ej8;

import java.util.ArrayList;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Vehiculo {

	private String patente;
	private Llave llave;
	private ArrayList<Persona> autorizadas;
	private int mesesAdeudados;

	public Vehiculo(String patente, int mesesAdeudados) {
		setPatente(patente);
		this.llave = new Llave(patente);
		setMesesAdeudados(mesesAdeudados);
		this.autorizadas =  new ArrayList<Persona>();
	}
	


	private void setPatente(String patente) {
		this.patente = patente;
	}

	private void setMesesAdeudados(int mesesAdeudados) {
		this.mesesAdeudados = mesesAdeudados;
	}

	public int getMesesAdeudados() {
		return this.mesesAdeudados;
	}

	public void imprimirPatente() {
		System.out.println("Vehiculo: patente "+patente);
	}



	public boolean mismaPatente(String patente) {
		
		return this.patente.equals(patente);
	}



	public boolean deudor(int LIMITE_MESES) {
	
		return this.mesesAdeudados >= LIMITE_MESES ;
	}



	public Llave darLlave() {
		Llave llave = this.llave;
		this.llave = null;
		return llave;
	}



	public String getPatente() {
		return this.patente;
	}



	public boolean esAutorizada(String dni) {
		boolean autorizada =  false;
		int i = 0;
		while(i < this.autorizadas.size() && autorizada == false) {
			if(this.autorizadas.get(i).mismoDni(dni)) {
				autorizada = true;
			}else {
				i++;
			}
		}
		return autorizada;
	}



	public boolean agregarPersona(Persona p1) {
		boolean agregada = false;
		int i = 0;
		
		while(i < this.autorizadas.size() && agregada == false) {
			if(this.autorizadas.get(i).mismoDni(p1.getDni())) {
				agregada = true;
			}else {
				i++;
			}
			
		}
		
		if(agregada == false) {
			this.autorizadas.add(p1);
			agregada = true;
		}
		return agregada;
		
	}



	

}