package ej10;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Carta {

	private int numero;
	private PaloCarta palo;

	public Carta(int numero, PaloCarta paloCarta) {
		setNumero(numero);
		setPalo(paloCarta);
	}

	private void setNumero(int numero) {
		this.numero = numero;
	}

	private void setPalo(PaloCarta palo) {
		this.palo = palo;
	}
	
	

}