package ej10;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public enum Resultado {

	SIN_DISPONIBILIDAD,
	JUEGO_NO_ENCONTRADO,
	ASIGNACION_OK;

}