package ej10;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class DisponibilidadJuego {

	private String nombre;
	private int cantDisponible;

	public DisponibilidadJuego(String nombre, int cantDisp) {
		setNombre(nombre);
		setCantDisponible(cantDisp);
	}

	private void setNombre(String nombre) {
		this.nombre = nombre;
	}

	private void setCantDisponible(int cantDisponible) {
		this.cantDisponible = cantDisponible;
	}
	
	

}