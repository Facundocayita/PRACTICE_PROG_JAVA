package ej10;

import java.util.ArrayList;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Mesa {

	private int numero;
	private int cantMaxPart;
	private ArrayList<Participante> participantesJugando;
	private ArrayList<Carta> mazo;
	private final int CANT_CARTAS_A_REPARTIR = 4;

	public Mesa(int numero, int cantMaxPart) {
		setNumero(numero);
		setCantMaxPart(cantMaxPart);
		participantesJugando = new ArrayList<Participante>();
		mazo = new ArrayList<Carta>();
	}
	
	

	private void setNumero(int numero) {
		this.numero = numero;
	}



	private void setCantMaxPart(int cantMaxPart) {
		this.cantMaxPart = cantMaxPart;
	}



	public boolean repartirCartas() {
		boolean repartioTotal = false;
		boolean repartioRonda = true;
		int i = 0;
		
		while(i< this.CANT_CARTAS_A_REPARTIR && repartioRonda == true) {
			repartioRonda =repartir1RondaCartas();
			i++;
		}
		
		if(i == CANT_CARTAS_A_REPARTIR) {
			repartioTotal = true;
		}
		
		return repartioTotal;
	}



	private boolean repartir1RondaCartas() {
		int i = 0;
		boolean repartio = false;
		
		while(i<this.participantesJugando.size() && !mazo.isEmpty()) {
			participantesJugando.get(i).darCarta(this.mazo.get(0));
			mazo.remove(0);
			i++;
		}
		
		if( i == this.participantesJugando.size()) {
			repartio = true;
		}
		
		return repartio;
	}



	public int obtenerDispo() {
		return this.cantMaxPart - this.participantesJugando.size();
	}

}