package ej10;

import java.util.ArrayList;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Juego {

	private String nombre;
	private ArrayList<Mesa> mesas;

	public Juego(String nombre) {
		setNombre(nombre);
		mesas = new ArrayList<Mesa>();
	}
	
	

	private void setNombre(String nombre) {
		this.nombre = nombre;
	}



	public DisponibilidadJuego obtenerDisponibilidad() {
		
		 DisponibilidadJuego dispJuegos = new DisponibilidadJuego(this.nombre, this.obtenerDispo());
		
		return dispJuegos;
	}



	private int obtenerDispo() {
		int dispo = 0;
		for(Mesa m: this.mesas) {
			dispo += m.obtenerDispo();
		}
		return dispo;
	}

}