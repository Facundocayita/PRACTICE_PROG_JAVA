package ej10;

import java.util.ArrayList;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Participante {

	private String nombre;
	private int edad;
	private ArrayList<Carta> cartasEnLaMano;

	public Participante(String nombre, int edad) {
		setNombre(nombre);
		setEdad(edad);
		cartasEnLaMano = new ArrayList<Carta>();
	}

	private void setNombre(String nombre) {
		this.nombre = nombre;
	}

	private void setEdad(int edad) {
		this.edad = edad;
	}

	public void darCarta(Carta carta) {
		cartasEnLaMano.add(carta);
		
	}
	
	

}