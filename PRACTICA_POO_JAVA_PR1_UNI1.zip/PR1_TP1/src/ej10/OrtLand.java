package ej10;

import java.util.ArrayList;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class OrtLand {

	private ArrayList<Juego> juegos;

	public Resultado acomodarJugador(String nombreJugador, int edad, String nombreJuego) {
		// Método a resolver...
		return null;
	}
	
	public ArrayList<DisponibilidadJuego> obtenerDisponibilidadJuegos() {
		ArrayList<DisponibilidadJuego> dispJuegos = new ArrayList<DisponibilidadJuego>();
		
		for(Juego j: this.juegos) {
			dispJuegos.add(j.obtenerDisponibilidad());
		}
		
		return dispJuegos;
	}

}