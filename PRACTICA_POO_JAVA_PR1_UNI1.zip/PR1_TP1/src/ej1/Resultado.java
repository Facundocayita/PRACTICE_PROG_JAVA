package ej1;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public enum Resultado {

	CURSO_INEX,
	USUARIO_INEX,
	ES_AUTOR,
	MAX_BECADOS,
	SUSCRIPTO_OK,
	YA_SUSCRIPTO;

}