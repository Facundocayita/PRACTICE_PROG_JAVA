package ej1;

import java.util.ArrayList;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Categoria {

	private String id;
	private String nombre;
	private ArrayList<Curso> cursos;

	public Categoria(String id, String nombre) {
		setNombre(nombre);
		setId(id);
		cursos = new ArrayList<Curso>();
	}

	public Curso buscarCurso(String idCurso) {
		Curso encontrado = null;
		int i = 0;
		
		while(i < this.cursos.size() && !this.cursos.get(i).mismoId(idCurso)) {
			i++;
		}
		if(i < this.cursos.size()) {
			encontrado = this.cursos.get(i);
		}
		return encontrado;
	}

	

	private void setNombre(String nombre) {
		this.nombre = nombre;
	}

	private void setId(String id) {
		this.id = id;
	}

	public void agregarCurso(Curso c) {
		if(c != null && existeElCurso(c)) {
		this.cursos.add(c);
		}
		
	}

	private boolean existeElCurso(Curso c) {
	
		return this.cursos.contains(c);
	}
	
	

}