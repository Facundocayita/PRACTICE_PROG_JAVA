package ej1;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public enum TipoLeccion {

	TEXTO,
	VIDEO,
	RECURSO;

}