package ej1;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Principal {

	public static void main(String[] args) {
		Ortdemy ortdemy = new Ortdemy();
		cargarUniverso(ortdemy);
		System.out.println(ortdemy.suscribirseACurso("01", "java1")); // ES_AUTOR
		System.out.println(ortdemy.suscribirseACurso("02", "pasteleria1")); // SUSCRIPTO_OK
		System.out.println(ortdemy.suscribirseACurso("04", "pasteleria1")); // USUARIO_INEX
		System.out.println(ortdemy.suscribirseACurso("03", "fakeCurso")); // CURSO_INEX
		System.out.println(ortdemy.suscribirseACurso("03", "java1")); // SUSCRIPTO_OK
		System.out.println(ortdemy.suscribirseACurso("04", "java1")); // SUSCRIPTO_OK
		System.out.println(ortdemy.suscribirseACurso("05", "java1")); // SUSCRIPTO_OK
		System.out.println(ortdemy.suscribirseACurso("06", "java1")); // SUSCRIPTO_OK
		System.out.println(ortdemy.suscribirseACurso("07", "java1")); // SUSCRIPTO_OK
		System.out.println(ortdemy.suscribirseACurso("08", "java1")); // MAX_BECADOS


	}
	
	public static void cargarUniverso(Ortdemy ortdemy) {
		Usuario u1 = new Usuario("01", "Pedro", "pedro@mail.com", false);
		Usuario u2 = new Usuario("02", "Juan", "juan@mail.com", false);
		Usuario u3 = new Usuario("03", "Becado1", "becado1@mail.com", true);
		Usuario u4 = new Usuario("04", "Becado2", "becado2@mail.com", true);
		Usuario u5 = new Usuario("05", "Becado3", "becado3@mail.com", true);
		Usuario u6 = new Usuario("06", "Becado4", "becado4@mail.com", true);
		Usuario u7 = new Usuario("07", "Becado5", "becado5@mail.com", true);
		Usuario u8 = new Usuario("08", "Becado6", "becado6@mail.com", true);

		
		
		Categoria cat1  = new Categoria("PROG_1", "Programacion 1");
		Categoria cat2  = new Categoria("COCINA", "Cocina 1");
		
		Curso c1 = new Curso("java1", "java", 100, 5, u1);
		Curso c2 = new Curso("C++1", "c++", 100, 5, u1);
		Curso c3 = new Curso("pasteleria1", "facturas", 100, 5, u1);
		Curso c4 = new Curso("sushi1", "sushi", 100, 5, u1);
		
		cat1.agregarCurso(c1);
		cat1.agregarCurso(c2);
		cat2.agregarCurso(c3);
		cat2.agregarCurso(c4);
		
		ortdemy.agregarCategoria(cat1);
		ortdemy.agregarCategoria(cat2);
		
		ortdemy.agregarUsuario(u1);
		ortdemy.agregarUsuario(u2);
		ortdemy.agregarUsuario(u3);
		ortdemy.agregarUsuario(u4);
		ortdemy.agregarUsuario(u5);
		ortdemy.agregarUsuario(u6);
		ortdemy.agregarUsuario(u7);
		ortdemy.agregarUsuario(u8);

		
		
	}

}