package ej1;

import java.util.ArrayList;

/**
 * Código generado por la app UXFtoJava by Charly Cimino
 * @see https://github.com/CharlyCimino/uxf-to-java
 */
public class Ortdemy {

	private ArrayList<Usuario> usuarios;
	private ArrayList<Categoria> categorias;



	public Ortdemy() {
		usuarios = new ArrayList<Usuario>();
		categorias = new ArrayList<Categoria>();

	}



	public Resultado suscribirseACurso(String idUsuario, String idCurso) {
		Resultado res = Resultado.SUSCRIPTO_OK;

		Usuario u = buscarUsuario(idUsuario);
		if(u == null) {
			res = Resultado.USUARIO_INEX;
		}else {
			Curso c = buscarCurso(idCurso);
			if(c == null) {
				res = Resultado.CURSO_INEX;
			}else if(c.esAutor(idUsuario)) {
				res = Resultado.ES_AUTOR;
			}else if(u.esBecado() && !c.hayVacantesParaBecados()) {
				res = Resultado.MAX_BECADOS;
			}else if(c.estaSuscripto(u)) {
				res = Resultado.YA_SUSCRIPTO;
			}else {
				c.suscribir(u);
			}
		}
		return res;
	}




	private Curso buscarCurso(String idCurso) {
		Curso encontrado = null;
		int i = 0;

		while(i < this.categorias.size() && encontrado == null) {
			encontrado = this.categorias.get(i).buscarCurso(idCurso);
			i++;
		}
		return encontrado;
	}



	private Usuario buscarUsuario(String idUsuario) {
		Usuario encontrado = null;
		int i = 0;

		while(i < this.usuarios.size() && !this.usuarios.get(i).mismoId(idUsuario)) {
			i++;
		}
		if(i < this.usuarios.size()) {
			encontrado = this.usuarios.get(i);
		}
		return encontrado;
	}



	public void agregarCategoria(Categoria cat) {
		this.categorias.add(cat);
		
	}


	public void agregarUsuario(Usuario u) {
		this.usuarios.add(u);
		
	}

}