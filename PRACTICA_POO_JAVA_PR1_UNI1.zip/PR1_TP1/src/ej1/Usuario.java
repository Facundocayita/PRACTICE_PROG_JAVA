package ej1;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Usuario {

	private String id;
	private String nombre;
	private String mail;
	private boolean becado;

	public Usuario(String id, String nombre, String mail, boolean becado) {
		setId(id);
		setNombre(nombre);
		setMail(mail);
		setBecado(becado);
	}

	public boolean mismoId(String idUsuario) {
		boolean mismoId = false;
		if(this.id.equals(idUsuario)) {
			mismoId = true;
		}
		return mismoId;
	}

	private void setId(String id) {
		this.id = id;
	}

	private void setNombre(String nombre) {
		this.nombre = nombre;
	}

	private void setMail(String mail) {
		this.mail = mail;
	}

	private void setBecado(boolean becado) {
		this.becado = becado;
	}

	public boolean esBecado() {
		boolean esBecado = false;
		if(this.becado) {
			esBecado = true;
		}
		return esBecado;
	}

	


	
	

}