package ej1;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Leccion {

	private String nombre;
	private int duracion;
	private TipoLeccion tipo;

	public Leccion(String nombre, int duracion, TipoLeccion tipo) {
		setNombre(nombre);
		setDuracion(duracion);
		setTipo(tipo);
	}

	private void setNombre(String nombre) {
		this.nombre = nombre;
	}

	private void setDuracion(int duracion) {
		this.duracion = duracion;
	}

	private void setTipo(TipoLeccion tipo) {
		this.tipo = tipo;
	}
	
	

}