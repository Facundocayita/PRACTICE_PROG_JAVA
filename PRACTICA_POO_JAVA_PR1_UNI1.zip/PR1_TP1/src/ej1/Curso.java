package ej1;

import java.util.ArrayList;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Curso {

	private static final int LIMITE_BECADOS = 5;
	private String id;
	private String titulo;
	private double precio;
	private int valoracion;
	private int cantBecados;
	private Usuario autor;
	private ArrayList<Leccion> lecciones;
	private ArrayList<Usuario> suscriptos;

	public Curso(String id, String titulo, double precio, int valoracion, Usuario autor) {
		setId(id);
		setTitulo(titulo);
		setPrecio(precio);
		setValoracion(valoracion);
		setAutor(autor);
		setCantBecados();
		lecciones = new ArrayList<Leccion>();
		suscriptos = new ArrayList<Usuario>();
	}

	private void setId(String id) {
		this.id = id;
	}

	private void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	private void setPrecio(double precio) {
		this.precio = precio;
	}

	private void setValoracion(int valoracion) {
		this.valoracion = valoracion;
	}

	private void setCantBecados() {
		this.cantBecados = 0;
	}

	private void setAutor(Usuario autor) {
		this.autor = autor;
	}

	public boolean mismoId(String idCurso) {
		return this.id.equals(idCurso);
	}

	public boolean esAutor(String idUsuario) {
		boolean esAutor = false;
		
		if(this.autor.mismoId(idUsuario)){
			esAutor = true;
		}
		return esAutor;
	}

	public boolean hayVacantesParaBecados() {
		return cantBecados < LIMITE_BECADOS;
	}

	public void suscribir(Usuario u) {
		
		if(!estaSuscripto(u) && u != null) {
		if(u.esBecado()) {
			if(hayVacantesParaBecados()) {
				this.suscriptos.add(u);
				cantBecados++;
			}
		}else {
			this.suscriptos.add(u);

		}
		}
	}

	public boolean estaSuscripto(Usuario u) {
		return this.suscriptos.contains(u);
	}

	

	
	
	

}