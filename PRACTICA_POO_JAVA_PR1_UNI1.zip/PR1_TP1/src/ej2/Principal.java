package ej2;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Principal {

	public static void main(String[] args) {
		Hotel hotel = new Hotel("Hilto", "Corrientes 122");
		cargarDatos(hotel);
		
		
	}
	
	public static void cargarDatos(Hotel h) {
		
		Habitacion h1 = new Habitacion(1, 100);
		Habitacion h2 = new Habitacion(2, 200);
		Habitacion h3 = new Habitacion(3, 300);
		Habitacion h4 = new Habitacion(4, 400);
		
		h.agregarHabitacion(h1);
		h.agregarHabitacion(h2);
		h.agregarHabitacion(h3);
		h.agregarHabitacion(h4);
		
		h.realizarCheckin(h1, 5);
		
		
		System.out.println(h1.calcularTotal());
		
		Adicional a1 = new Adicional(150, "2 de agosto", TipoAdicional.TRASLADO);
		Adicional a2 = new Adicional(200, "2 de agosto", TipoAdicional.DESAYUNO);
		Adicional a3 = new Adicional(150, "2 de agosto", TipoAdicional.ROOM_SERVICE);
		
		h.agregarAdicional(h1, a1);
		h.agregarAdicional(h1, a2);
		h.agregarAdicional(h1, a3);
		
		System.out.println(h1.calcularTotal());
		
		h.imprimirHabitacionesDisponibles();
	}

}