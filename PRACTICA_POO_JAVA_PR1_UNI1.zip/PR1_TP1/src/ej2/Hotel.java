package ej2;

import java.util.ArrayList;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Hotel {

	private String nombre;
	private String direccion;
	private ArrayList<Habitacion> habitaciones;

	public Hotel(String nombre, String direccion) {
		setNombre(nombre);
		setDireccion(direccion);
		this.habitaciones = new ArrayList<>();
	}
	
	

	private void setNombre(String nombre) {
		this.nombre = nombre;
	}



	private void setDireccion(String direccion) {
		this.direccion = direccion;
	}



	private ArrayList<Habitacion> obtenerHabitacionesDisponibles() {
		
		ArrayList<Habitacion> habitacionesDispo = new ArrayList<>();
		
		if(!this.habitaciones.isEmpty()) {
			for(Habitacion h: this.habitaciones) {
				if(!h.getOcupada()) {
					habitacionesDispo.add(h);
				}
			}
		}
		
		return habitacionesDispo;
	}
	
	
	public void imprimirHabitacionesDisponibles() {
		ArrayList<Habitacion> d = obtenerHabitacionesDisponibles();
		
		for(Habitacion dispo: d) {
			System.out.println(dispo);
			
		}
	}

	public double realizarCheckout(int numHabitacion) {
		double montoAAbonar = -1;
		
		Habitacion h = buscarHabitacion(numHabitacion);
		if(h != null && h.getOcupada()) {
			montoAAbonar = h.calcularTotal();
			
		}
		return montoAAbonar;
	}



	private Habitacion buscarHabitacion(int numHabitacion) {
		Habitacion encontrada = null;
		int i = 0;
		
		while(i < this.habitaciones.size() && !this.habitaciones.get(i).mismoNumero(numHabitacion)) {
			i++;	
		}
		
		if(this.habitaciones.get(i).mismoNumero(numHabitacion)) {
			encontrada = this.habitaciones.get(i);
		}
		
		return encontrada;
	}
	

	public void agregarHabitacion(Habitacion h1) {
		if(!this.habitaciones.contains(h1)) {
			this.habitaciones.add(h1);
		}
		
	}
	



	public void realizarCheckin(Habitacion h1, int dias) {
		if(this.habitaciones.contains(h1)) {
			h1.cambiarDiasOcupadas(dias);
			h1.cambiarOcupada(true);
		}
		
	}



	public void agregarAdicional(Habitacion h1, Adicional a1) {
		Habitacion encontrada = buscarHabitacion(h1.getNumero());
		if(encontrada != null) {
			encontrada.agregarAdicional(a1);
		}
		
	}
	
	

}