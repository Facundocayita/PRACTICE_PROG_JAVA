package ej2;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Adicional {

	private double precio;
	private String fecha;
	private TipoAdicional tipo;

	public Adicional(double precio, String fecha, TipoAdicional tipo) {
		setPrecio(precio);
		setFecha(fecha);
		setTipo(tipo);
		
	}

	private void setPrecio(double precio) {
		this.precio = precio;
	}

	private void setFecha(String fecha) {
		this.fecha = fecha;
	}

	private void setTipo(TipoAdicional tipo) {
		this.tipo = tipo;
	}

	public double getPrecio() {
		return this.precio;
	}
	
	

}