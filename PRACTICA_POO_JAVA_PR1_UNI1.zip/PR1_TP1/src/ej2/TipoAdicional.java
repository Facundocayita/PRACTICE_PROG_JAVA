package ej2;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public enum TipoAdicional {

	DESAYUNO,
	ROOM_SERVICE,
	TRASLADO;

}