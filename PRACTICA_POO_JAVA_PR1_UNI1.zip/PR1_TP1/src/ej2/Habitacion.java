package ej2;

import java.util.ArrayList;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Habitacion {

	private int numero;
	private double precioXDia;
	private boolean ocupada;
	private String nombreCiente;
	private int diasEstadia;
	private ArrayList<Adicional> adicionales;

	public Habitacion(int numero, double precioXDia) {
		setNumero(numero);
		setPrecioXDia(precioXDia);
		setOcupada();
		this.adicionales = new ArrayList<>();
	}
	
	

	private void setNumero(int numero) {
		this.numero = numero;
	}



	private void setPrecioXDia(double precioXDia) {
		this.precioXDia = precioXDia;
	}



	private void setOcupada() {
		this.ocupada = false;
	}
	
	private double calcularEstadiaSimple() {
		return precioXDia * diasEstadia;
	}
	
	private double calcularPrecioAdicionales() {
		double precioAdicionales = 0;
	
		for(Adicional a: this.adicionales) {
				precioAdicionales += a.getPrecio();
		}
		return precioAdicionales;
	}



	public double calcularTotal() {
		double precioEstadiaTotal = calcularEstadiaSimple();
		if(!this.adicionales.isEmpty()) {
			precioEstadiaTotal += calcularPrecioAdicionales();			
		}
		
		return precioEstadiaTotal;
	}



	public boolean getOcupada() {
		
		return this.ocupada;
	}



	public boolean mismoNumero(int numHabitacion) {
		
		return numHabitacion == this.numero;
	}



	public void cambiarDiasOcupadas(int dias) {
		this.diasEstadia = dias;
		
	}



	public void cambiarOcupada(boolean ocupada) {
		this.ocupada = ocupada;
		
	}



	public int getNumero() {
		return this.numero;
	}



	public void agregarAdicional(Adicional a1) {
		this.adicionales.add(a1);
		
	}



	@Override
	public String toString() {
		return "Habitacion [numero=" + numero + ", ocupada=" + ocupada + ", diasEstadia=" + diasEstadia + "]";
	}
	
	

}